package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.inventory.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Datapack'teki tarifler:
 *
 *  Dövme masası (şablon boş, taban netherite alet, ekleme Ruby Bloğu):
 *      netherite_sword    + Ruby Bloğu -> Ruby Sword
 *      netherite_axe      + Ruby Bloğu -> Ruby Axe
 *      netherite_pickaxe  + Ruby Bloğu -> Ruby Pickaxe
 *      netherite_shovel   + Ruby Bloğu -> Ruby Shovel
 *      netherite_hoe      + Ruby Bloğu -> Ruby Hoe
 *      netherite_helmet / chestplate / leggings / boots + Ruby Bloğu -> Ruby zırh
 *  Şablon Ruby Bloğu olursa:
 *      Ruby Bloğu + netherite_axe + Ruby Bloğu -> Ruby Savaş Baltası
 *
 *  Tezgâh:
 *      9x Ruby Tozu -> 1 Ruby        |  1 Ruby     -> 9 Ruby Tozu
 *      1 Ruby Bloğu -> 9 Ruby        |  (blok tarifi datapack'teki gibi)
 *
 * Sonuç eşyası önizlemede işaretçi olarak gösterilir; oyuncu alınca gerçek eşya
 * birebir aynı bileşenlerle teslim edilir.
 */
public final class RubyRecipes implements Listener {

    private final CursedPack plugin;

    /** netherite taban -> (ruby esya adi, gorunen isim) */
    private static final Map<Material, String> SMITH = new HashMap<>();
    static {
        SMITH.put(Material.NETHERITE_SWORD, "sword");
        SMITH.put(Material.NETHERITE_AXE, "axe");
        SMITH.put(Material.NETHERITE_PICKAXE, "pickaxe");
        SMITH.put(Material.NETHERITE_SHOVEL, "shovel");
        SMITH.put(Material.NETHERITE_HOE, "hoe");
        SMITH.put(Material.NETHERITE_HELMET, "helmet");
        SMITH.put(Material.NETHERITE_CHESTPLATE, "chestplate");
        SMITH.put(Material.NETHERITE_LEGGINGS, "leggings");
        SMITH.put(Material.NETHERITE_BOOTS, "boots");
    }

    private static final Map<String, String> DISPLAY = Map.of(
            "sword", "Ruby Sword", "axe", "Ruby Axe", "pickaxe", "Ruby Pickaxe",
            "shovel", "Ruby Shovel", "hoe", "Ruby Hoe", "helmet", "Ruby Helmet",
            "chestplate", "Ruby Chestplate", "leggings", "Ruby Leggings", "boots", "Ruby Boots");

    public RubyRecipes(CursedPack plugin) {
        this.plugin = plugin;
        registerCrafting();
    }

    // ------------------------------------------------------------ dovme masasi

    @EventHandler
    public void onPrepareSmith(PrepareSmithingEvent e) {
        SmithingInventory inv = e.getInventory();
        ItemStack template = inv.getItem(0);
        ItemStack base = inv.getItem(1);
        ItemStack addition = inv.getItem(2);

        if (base == null || addition == null) return;
        if (!CursedPack.isModel(addition, "ruby/ruby_block")) return;

        boolean templateIsRuby = template != null && CursedPack.isModel(template, "ruby/ruby_block");
        boolean templateEmpty = template == null || template.getType().isAir();

        String key;
        String name;
        if (templateIsRuby && base.getType() == Material.NETHERITE_AXE) {
            key = "war_axe";
            name = "Ruby Savaş Baltası";
        } else if (templateEmpty && SMITH.containsKey(base.getType())) {
            key = SMITH.get(base.getType());
            name = DISPLAY.get(key);
        } else {
            return;
        }

        e.setResult(marker(base.getType(), key, name));
    }

    /**
     * Önizleme eşyası: doğru 3B model ve isim taşır ama gerçek eşya değildir.
     * Oyuncu sonucu alınca gerçek eşya ile değiştirilir.
     */
    private ItemStack marker(Material type, String giveKey, String name) {
        ItemStack st = new ItemStack(type);
        ItemMeta m = st.getItemMeta();
        m.displayName(Component.text(name));
        try {
            String model = giveKey.equals("war_axe") ? "ruby/ruby_war_axe" : "ruby/ruby_" + giveKey;
            m.setItemModel(new NamespacedKey("minecraft", "item/" + model));
        } catch (Throwable ignored) { }
        m.getPersistentDataContainer().set(
                new NamespacedKey(plugin, "recipe_result"),
                org.bukkit.persistence.PersistentDataType.STRING, giveKey);
        st.setItemMeta(m);
        return st;
    }

    // ------------------------------------------------------------ tezgah

    private void registerCrafting() {
        // 9 Ruby Tozu -> 1 Ruby
        ShapedRecipe dustToRuby = new ShapedRecipe(new NamespacedKey(plugin, "dust_to_ruby"),
                marker(Material.ECHO_SHARD, "ruby", "Ruby"));
        dustToRuby.shape("###", "###", "###");
        dustToRuby.setIngredient('#', Material.HEART_OF_THE_SEA);
        add(dustToRuby);

        // 1 Ruby -> 9 Ruby Tozu
        ItemStack dust9 = marker(Material.HEART_OF_THE_SEA, "ruby_dust", "Ruby Tozu");
        dust9.setAmount(9);
        ShapelessRecipe rubyToDust = new ShapelessRecipe(new NamespacedKey(plugin, "ruby_to_dust"), dust9);
        rubyToDust.addIngredient(Material.ECHO_SHARD);
        add(rubyToDust);

        // 1 Ruby Bloğu -> 9 Ruby
        ItemStack ruby9 = marker(Material.ECHO_SHARD, "ruby", "Ruby");
        ruby9.setAmount(9);
        ShapelessRecipe blockToRuby = new ShapelessRecipe(new NamespacedKey(plugin, "block_to_ruby"), ruby9);
        blockToRuby.addIngredient(Material.QUARTZ_BRICKS);
        add(blockToRuby);

        // 9 Ruby -> 1 Ruby Bloğu
        ShapedRecipe rubyToBlock = new ShapedRecipe(new NamespacedKey(plugin, "ruby_to_block"),
                marker(Material.QUARTZ_BRICKS, "ruby_block", "Ruby Bloğu"));
        rubyToBlock.shape("###", "###", "###");
        rubyToBlock.setIngredient('#', Material.ECHO_SHARD);
        add(rubyToBlock);
    }

    private void add(Recipe r) {
        try {
            Bukkit.addRecipe(r);
        } catch (Throwable t) {
            plugin.getLogger().warning("Tarif eklenemedi: " + t.getMessage());
        }
    }

    /** Sıradan echo_shard / heart_of_the_sea ile tarif çalışmasın — Ruby olmalı. */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        Recipe r = e.getRecipe();
        if (!(r instanceof Keyed k)) return;
        if (!k.getKey().getNamespace().equals(plugin.getName().toLowerCase())) return;

        String needed = switch (k.getKey().getKey()) {
            case "dust_to_ruby" -> "ruby/ruby_dust";
            case "ruby_to_dust" -> "ruby/ruby";
            case "block_to_ruby" -> "ruby/ruby_block";
            case "ruby_to_block" -> "ruby/ruby";
            default -> null;
        };
        if (needed == null) return;

        for (ItemStack st : e.getInventory().getMatrix()) {
            if (st == null || st.getType().isAir()) continue;
            if (!CursedPack.isModel(st, needed)) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }

    // ------------------------------------------------------------ sonucu teslim et

    @EventHandler
    public void onCraft(CraftItemEvent e) {
        deliver(e.getCurrentItem(), e.getWhoClicked());
    }

    @EventHandler
    public void onSmithTake(org.bukkit.event.inventory.InventoryClickEvent e) {
        if (!(e.getInventory() instanceof SmithingInventory)) return;
        if (e.getRawSlot() != 3) return;   // sonuc slotu
        deliver(e.getCurrentItem(), e.getWhoClicked());
    }

    /** İşaretçiyi gerçek eşya ile değiştir. */
    private void deliver(ItemStack marker, org.bukkit.entity.HumanEntity who) {
        if (marker == null || !marker.hasItemMeta()) return;
        if (!(who instanceof Player p)) return;

        String key = marker.getItemMeta().getPersistentDataContainer().get(
                new NamespacedKey(plugin, "recipe_result"),
                org.bukkit.persistence.PersistentDataType.STRING);
        if (key == null) return;

        int amount = marker.getAmount();
        Bukkit.getScheduler().runTask(plugin, () -> {
            // isaretcileri envanterden temizle
            for (int i = 0; i < p.getInventory().getSize(); i++) {
                ItemStack st = p.getInventory().getItem(i);
                if (st == null || !st.hasItemMeta()) continue;
                if (st.getItemMeta().getPersistentDataContainer().has(
                        new NamespacedKey(plugin, "recipe_result"),
                        org.bukkit.persistence.PersistentDataType.STRING)) {
                    p.getInventory().setItem(i, null);
                }
            }
            for (int n = 0; n < amount; n++) Items.give(p, key);
        });
    }
}
