package net.mrwqlf.cursedpack;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Eşya örnekleri (prototip) deposu.
 *
 * Eşyalar vanilla "give" komutuyla üretiliyor; bu yüzden Java tarafında elimizde
 * hazır bir ItemStack yok. Tariflerin SONUCU gerçek eşya olmalı, yoksa tarif
 * kitabında bozuk/mor doku ve yanlış tooltip görünüyor.
 *
 * Çözüm: bir kez "/cursedpack cache" çalıştırılır. Her eşya oyuncuya verilir,
 * ItemStack olarak yakalanır, envanterden alınır ve items.yml'ye yazılır.
 * Sonraki açılışlarda dosyadan okunur ve tarifler gerçek eşya ile kaydedilir.
 */
public final class ItemCache {

    private final CursedPack plugin;
    private final File file;
    private final Map<String, ItemStack> items = new HashMap<>();

    public ItemCache(CursedPack plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "items.yml");
        load();
    }

    public boolean isEmpty() { return items.isEmpty(); }

    public int size() { return items.size(); }

    public ItemStack get(String key) {
        ItemStack st = items.get(key);
        return st == null ? null : st.clone();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            ItemStack st = y.getItemStack(k);
            if (st != null) items.put(k, st);
        }
        plugin.getLogger().info("Eşya önbelleği yüklendi: " + items.size() + " eşya.");
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        items.forEach(y::set);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (Exception e) {
            plugin.getLogger().warning("items.yml yazılamadı: " + e.getMessage());
        }
    }

    /**
     * Tüm eşyaları oyuncuya verip yakalar, sonra envanterden temizler.
     * Envanterin boş olması gerekir.
     */
    public int rebuild(Player p) {
        items.clear();
        int ok = 0;

        for (String key : Items.names()) {
            int slot = firstEmpty(p);
            if (slot < 0) break;

            if (!Items.give(p, key)) continue;

            ItemStack got = p.getInventory().getItem(slot);
            if (got == null || got.getType().isAir()) continue;

            ItemStack one = got.clone();
            one.setAmount(1);
            items.put(key, one);
            p.getInventory().setItem(slot, null);
            ok++;
        }

        save();
        return ok;
    }

    private int firstEmpty(Player p) {
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getItem(i);
            if (st == null || st.getType().isAir()) return i;
        }
        return -1;
    }
}
