# CursedPack v2 — tamamen Java plugin

Datapack YOK. Tum yetenekler Bukkit event'leri olarak yazildi.

## Esyalar
`/cursedpack give <esya> [oyuncu]` — `/cursedpack list`

cekic, scythe, ruby, ruby_dust, ruby_block, sword, axe, war_axe,
pickaxe, shovel, hoe, spear, armor, helmet, chestplate, leggings, boots

## Java'ya cevrilen yetenekler
| Yetenek | Nerede |
|---|---|
| Adalet Cekici — 10+ blok dususte %40 deprem | `AdaletCekici.java` |
| War Scythe — sag tik firlat, cek, cooldown | `WarScythe.java` |
| Ruby Sword — yasam calma, kizil ofke | `RubyWeapons.java` |
| Ruby War Axe — %25 altinda isaretle, infaz et | `RubyWeapons.java` |
| Ruby Axe — agac yikici + elma sansi | `RubyTools.java` |
| Ruby Shovel — 3x3 kaz | `RubyTools.java` |
| Ruby Hoe — 5x5 hasat + yeniden ek | `RubyTools.java` |
| Ruby zirh — atilim / kan bagi / olumsuz kivilcim | `RubyArmor.java` |
| Ruby Ore — Nether y24-36 olusum + drop | `RubyOre.java` |
| Cursed Valley — harita insasi | `ValleyBuilder.java` |

Ayarlar `config.yml` icinde (cooldown, hasar, sans, ore yogunlugu).

## Cursed Valley
```
/cursedpack valley prep 1     # chunk yukle, ~2 dk bekle
/cursedpack valley build 1    # insa et
/cursedpack valley status     # ilerleme
/cursedpack valley stop       # durdur
/cursedpack valley finish     # forceload temizle + spawn ayarla
```
Sektor 1-9. Datapack surumunden farki: komutlar tik basina bolunerek
calisir, sunucu donmaz. Hizi `valley.commands-per-tick` ile ayarlarsin.

## Henuz Java'ya cevrilmedi
- Ruby Pickaxe — "Nether'in Gozu" maden parlatma
- Ruby Spear — elytra meteor
Esyalar veriliyor ve normal alet olarak calisiyor, ozel yetenekleri yok.

## Resourcepack
3D modeller hala resourcepack'ten geliyor — `server.properties` icindeki
`resource-pack` ayarini birak.
