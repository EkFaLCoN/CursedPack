package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Adalet Çekici — datapack davranisinin birebir karsiligi.
 *
 * Tetik  : cekicle bir varliga vurdugunda, son 3 tick icindeki en yuksek dusus
 *          mesafesi 10+ ise %40 ihtimalle deprem.
 * Deprem : oyuncunun altindaki ZEMINDE patlar (24 blok asagi taranir)
 *          5x2x5 alandaki hedeflere magic hasar = 12 - (zirh puani x 0.3), en az 0.01
 *          herkese 2 saniye Yavaşlık III
 *          %30 ihtimalle 2 saniye yere sabitleme
 */
public final class AdaletCekici implements Listener {

    private static final String MODEL = "adaletcekici/adaletcekici";
    private final CursedPack plugin;

    /** Son 3 tick'in dusus mesafesi (cekic vurusu fall_distance'i sifirladigi icin gerekli). */
    private final Map<UUID, float[]> fallHistory = new HashMap<>();
    private final Map<UUID, Integer> rootLeft = new HashMap<>();
    private final Map<UUID, Location> rootAnchor = new HashMap<>();
    private final Set<UUID> busy = new HashSet<>();
    /** Bir dususte deprem zarinin bir kez atilmasi icin. Yere degince temizlenir. */
    private final Set<UUID> usedThisFall = new HashSet<>();
    private final org.bukkit.NamespacedKey rootKey;

    public AdaletCekici(CursedPack plugin) {
        this.plugin = plugin;
        this.rootKey = new org.bukkit.NamespacedKey(plugin, "quake_root");
        startTicker();
    }

    private void startTicker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player p : plugin.getServer().getOnlinePlayers()) {
                    float[] h = fallHistory.computeIfAbsent(p.getUniqueId(), k -> new float[3]);
                    h[2] = h[1];
                    h[1] = h[0];
                    h[0] = p.getFallDistance();

                    // yere degdiyse yeni dusus baslayabilir
                    if (p.isOnGround()) usedThisFall.remove(p.getUniqueId());
                }
                tickRoots();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (busy.contains(p.getUniqueId())) return; // deprem hasari kendini tetiklemesin
        if (!CursedPack.isModel(p.getInventory().getItemInMainHand(), MODEL)) return;

        float[] h = fallHistory.get(p.getUniqueId());
        float max = p.getFallDistance();
        if (h != null) for (float f : h) max = Math.max(max, f);

        if (max < plugin.getConfig().getDouble("cekic.min-fall", 10.0)) return;

        // Ayni dusus icin ikinci kez zar atilmasin.
        // DIKKAT: setFallDistance(0) YAPMIYORUZ — o, gurzun Ruzgar Patlamasi
        // (wind_burst) buyusunu iptal ediyordu. Bunun yerine bayrak kullaniyoruz.
        if (usedThisFall.contains(p.getUniqueId())) return;
        usedThisFall.add(p.getUniqueId());

        int chance = plugin.getConfig().getInt("cekic.chance-percent", 40);
        if (new Random().nextInt(100) >= chance) {
            p.sendActionBar(Component.text("Deprem tetiklenmedi", NamedTextColor.DARK_GRAY));
            return;
        }
        quake(p);
    }

    private void quake(Player caster) {
        caster.sendActionBar(Component.text("DEPREM!", NamedTextColor.GOLD).decorate(TextDecoration.BOLD));
        busy.add(caster.getUniqueId());
        try {
            Location ground = findGround(caster.getLocation().clone());
            apply(caster, ground);
        } finally {
            busy.remove(caster.getUniqueId());
        }
    }

    /** Oyuncunun altinda en fazla 24 blok asagi tarayip zemini bulur. */
    private Location findGround(Location from) {
        Location l = from.clone();
        for (int i = 0; i < 24; i++) {
            Material below = l.clone().add(0, -1, 0).getBlock().getType();
            if (below != Material.AIR && below != Material.CAVE_AIR && below != Material.VOID_AIR) return l;
            l.add(0, -1, 0);
        }
        return l;
    }

    private void apply(Player caster, Location c) {
        c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 2.5f, 0.5f);
        c.getWorld().playSound(c, Sound.BLOCK_DEEPSLATE_BRICKS_BREAK, 3f, 0.6f);
        c.getWorld().playSound(c, Sound.ENTITY_RAVAGER_STUNNED, 1.5f, 0.8f);

        c.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, c.clone().add(0, 0.2, 0), 1, 0, 0, 0, 0);
        c.getWorld().spawnParticle(Particle.BLOCK, c.clone().add(0, 0.4, 0), 220, 2.2, 0.5, 2.2, 0.35,
                Material.DIRT.createBlockData());
        c.getWorld().spawnParticle(Particle.BLOCK, c.clone().add(0, 0.4, 0), 120, 2.2, 0.5, 2.2, 0.3,
                Material.STONE.createBlockData());
        c.getWorld().spawnParticle(Particle.CRIT, c.clone().add(0, 0.4, 0), 90, 2.2, 0.4, 2.2, 0.4);
        c.getWorld().spawnParticle(Particle.END_ROD, c.clone().add(0, 0.1, 0), 40, 2.5, 0.05, 2.5, 0);

        // datapack: dx=5, dy=2, dz=5 kutusu (~-2.5 ~-0.5 ~-2.5 noktasindan)
        Location box = c.clone().add(0, 0.5, 0);
        for (Entity ent : c.getWorld().getNearbyEntities(box, 2.5, 1.0, 2.5)) {
            if (!(ent instanceof LivingEntity le)) continue;
            if (le.equals(caster) || isImmune(le)) continue;
            hit(caster, le);
        }
    }

    private void hit(Player caster, LivingEntity target) {
        // hasar = 12 - (zirh puani x 0.3), en az 0.01 — magic hasar oldugu icin zirhi deler
        double armor = 0.0;
        var attr = target.getAttribute(Attribute.ARMOR);
        if (attr != null) armor = attr.getValue();

        double damage = 12.0 - (armor * 0.3);
        if (damage < 0.01) damage = 0.01;

        target.setNoDamageTicks(0); // bypasses_cooldown karsiligi
        target.damage(damage, caster);

        target.getWorld().spawnParticle(Particle.BLOCK, target.getLocation().add(0, 0.5, 0),
                25, 0.3, 0.5, 0.3, 0.15, Material.DIRT.createBlockData());

        // depremden etkilenen herkese 2 saniye Yavaslik III
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2, true, false, true));

        // %30 ihtimalle 2 saniye sabitleme
        if (new Random().nextInt(100) < 30) rootStart(target);
    }

    private void rootStart(LivingEntity target) {
        rootLeft.put(target.getUniqueId(), 40);
        rootAnchor.put(target.getUniqueId(), target.getLocation().clone());

        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 255, true, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 60, 128, true, false, false));

        var speed = target.getAttribute(Attribute.MOVEMENT_SPEED);
        if (speed != null && speed.getModifier(rootKey) == null) {
            speed.addModifier(new AttributeModifier(rootKey, -1.0,
                    AttributeModifier.Operation.ADD_SCALAR));
        }

        target.getWorld().playSound(target.getLocation(), Sound.BLOCK_CHAIN_PLACE, 1.5f, 0.6f);
        if (target instanceof Player tp) {
            tp.sendActionBar(Component.text("Deprem seni yere sabitledi!", NamedTextColor.RED)
                    .decorate(TextDecoration.BOLD));
        }
    }

    private void tickRoots() {
        Iterator<Map.Entry<UUID, Integer>> it = rootLeft.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            UUID id = en.getKey();
            Entity ent = plugin.getServer().getEntity(id);
            if (!(ent instanceof LivingEntity le) || !le.isValid()) {
                it.remove(); rootAnchor.remove(id); continue;
            }

            int left = en.getValue() - 1;
            le.getWorld().spawnParticle(Particle.BLOCK, le.getLocation().add(0, 0.1, 0),
                    6, 0.35, 0.05, 0.35, 0.02, Material.DIRT.createBlockData());

            if (left <= 0) {
                it.remove(); rootAnchor.remove(id);
                var speed = le.getAttribute(Attribute.MOVEMENT_SPEED);
                if (speed != null) {
                    var mod = speed.getModifier(rootKey);
                    if (mod != null) speed.removeModifier(mod);
                }
                le.removePotionEffect(PotionEffectType.SLOWNESS);
                le.removePotionEffect(PotionEffectType.JUMP_BOOST);
                continue;
            }
            en.setValue(left);

            Location anchor = rootAnchor.get(id);
            if (anchor == null) continue;
            Location back = anchor.clone();
            back.setYaw(le.getLocation().getYaw());
            back.setPitch(le.getLocation().getPitch());
            if (le.getLocation().distanceSquared(back) > 0.0001) le.teleport(back);
            le.setVelocity(new Vector(0, 0, 0));
        }
    }

    /** adaletcekici:quake_immune etiketi. */
    private boolean isImmune(LivingEntity le) {
        return switch (le.getType()) {
            case ARMOR_STAND, SHEEP, WOLF, CAT, COW, PIG, CHICKEN, HAPPY_GHAST,
                 VILLAGER, WANDERING_TRADER, HORSE, DONKEY, MULE,
                 SKELETON_HORSE, ZOMBIE_HORSE, WITHER, ENDER_DRAGON -> true;
            default -> false;
        };
    }
}
