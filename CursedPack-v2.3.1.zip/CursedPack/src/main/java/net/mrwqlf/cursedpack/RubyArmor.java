package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Ruby zirh:
 *   Alt set (bot + pantolon)  — Atilim: comelerek zipla, 6 blok ileri firla (20 sn)
 *   Ust set (kask + goguslük) — Kan Bagi: can %35 altina dusunce Direnc II
 *   Tam set                   — Olumsuz Kivilcim: can 1 kalbe dusunce Direnc IV,
 *                               Yenilenme II ve Ates Direnci (10 dk bekleme)
 *
 * Ruby Spear — Meteor: elytra ile suzulurken mizrak elde oldugu surece sabit hizda
 *              ilerlersin. Saniyede 5 dayaniklilik.
 */
public final class RubyArmor implements Listener {

    private final CursedPack plugin;

    private final Map<UUID, Integer> dashCd = new HashMap<>();    // tick
    private final Map<UUID, Integer> sparkCd = new HashMap<>();   // tick
    private final Map<UUID, Boolean> spearActive = new HashMap<>();
    private final Map<UUID, Integer> spearTick = new HashMap<>();

    public RubyArmor(CursedPack plugin) {
        this.plugin = plugin;
        startTicker();
    }

    private static boolean piece(ItemStack st, String name) {
        return CursedPack.isModel(st, "ruby/ruby_" + name);
    }

    static boolean lowerSet(Player p) {
        PlayerInventory i = p.getInventory();
        return piece(i.getBoots(), "boots") && piece(i.getLeggings(), "leggings");
    }

    static boolean upperSet(Player p) {
        PlayerInventory i = p.getInventory();
        return piece(i.getHelmet(), "helmet") && piece(i.getChestplate(), "chestplate");
    }

    // ------------------------------------------------------------------ atilim

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (!e.isSneaking()) return;
        Player p = e.getPlayer();
        if (!lowerSet(p)) return;
        if (p.isOnGround()) return;   // comelerek ZIPLA — havada olmali

        UUID id = p.getUniqueId();
        if (dashCd.getOrDefault(id, 0) > 0) {
            p.sendActionBar(Component.text("Atılım: " + ((dashCd.get(id) + 19) / 20) + " sn",
                    NamedTextColor.GRAY));
            return;
        }
        dashCd.put(id, 400);  // 20 saniye

        Vector dir = p.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
        dir.normalize().multiply(1.6).setY(0.25);
        p.setVelocity(dir);

        p.playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 0.9f, 1.3f);
        p.spawnParticle(Particle.DUST, p.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3,
                new Particle.DustOptions(Color.fromRGB(255, 38, 64), 1.4f));
        p.sendActionBar(Component.text("ATILIM", NamedTextColor.AQUA).decorate(TextDecoration.BOLD));
    }

    // ------------------------------------------------------------------ tick

    private void startTicker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                dashCd.replaceAll((k, v) -> Math.max(0, v - 1));
                sparkCd.replaceAll((k, v) -> Math.max(0, v - 1));

                for (Player p : plugin.getServer().getOnlinePlayers()) {
                    boolean up = upperSet(p);

                    if (up) bond(p);

                    spear(p);
                }
            }
        }.runTaskTimer(plugin, 20L, 1L);
    }

    /** Kan Bagi: can %35 veya altindaysa Direnc II. */
    private void bond(Player p) {
        double max = RubyWeapons.maxHealth(p);
        if (max <= 0) return;
        if (p.getHealth() <= max * 0.35) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 1, true, false, true));
        }
    }

    /**
     * Ölümsüz Kıvılcım — ölümcül darbeyi iptal eder, seni 1 kalple ayakta tutar.
     * Tam set gerekir, 10 dakika bekleme.
     */
    @EventHandler(ignoreCancelled = true, priority = org.bukkit.event.EventPriority.HIGHEST)
    public void onLethal(org.bukkit.event.entity.EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!(lowerSet(p) && upperSet(p))) return;

        // bu darbe öldürmüyorsa karışma
        if (p.getHealth() - e.getFinalDamage() > 0) return;

        UUID id = p.getUniqueId();
        if (sparkCd.getOrDefault(id, 0) > 0) return;
        sparkCd.put(id, 12000);  // 10 dakika

        e.setCancelled(true);
        p.setHealth(2.0);        // 1 kalp
        p.setFireTicks(0);

        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 120, 3, true, false, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1, true, false, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 160, 0, true, false, true));

        p.playSound(p.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1.4f);
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0),
                80, 0.5, 0.6, 0.5, 0.4);
        p.showTitle(Title.title(
                Component.text("ÖLÜMSÜZ KIVILCIM", NamedTextColor.LIGHT_PURPLE).decorate(TextDecoration.BOLD),
                Component.text("Bir kalple ayaktasın", NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(250), Duration.ofSeconds(2), Duration.ofMillis(500))));
    }

    // ------------------------------------------------------------------ meteor

    private void spear(Player p) {
        UUID id = p.getUniqueId();
        boolean ok = p.isGliding()
                && CursedPack.isModel(p.getInventory().getItemInMainHand(), "ruby/ruby_spear");

        if (!ok) {
            if (Boolean.TRUE.equals(spearActive.get(id))) {
                spearActive.put(id, false);
                spearTick.put(id, 0);
                p.playSound(p.getLocation(), Sound.ENTITY_PHANTOM_HURT, 0.3f, 1.6f);
                p.sendActionBar(Component.text(""));
            }
            return;
        }

        if (!Boolean.TRUE.equals(spearActive.get(id))) {
            spearActive.put(id, true);
            spearTick.put(id, 0);
            p.playSound(p.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 0.8f, 1.4f);
            p.sendActionBar(Component.text("Meteor kadar hızlısın...", NamedTextColor.LIGHT_PURPLE)
                    .decorate(TextDecoration.BOLD));
        }

        int t = (spearTick.getOrDefault(id, 0) + 1) % 20;
        spearTick.put(id, t);

        // sabit itis
        Vector dir = p.getLocation().getDirection().normalize().multiply(1.6);
        p.setVelocity(p.getVelocity().multiply(0.4).add(dir.multiply(0.6)));

        // iz parcacigi (4 tick'te bir)
        if (t % 4 == 0) {
            p.getWorld().spawnParticle(Particle.DUST,
                    p.getLocation().subtract(p.getLocation().getDirection().multiply(0.6)),
                    2, 0.1, 0.1, 0.1,
                    new Particle.DustOptions(Color.fromRGB(255, 38, 64), 1.0f));
        }

        // saniyede bir 5 dayaniklilik
        if (t == 0) {
            ItemStack spear = p.getInventory().getItemInMainHand();
            int left = RubyTools.durabilityLeft(spear);
            if (left <= 8) {
                p.getInventory().setItemInMainHand(null);
                p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
                spearActive.put(id, false);
                return;
            }
            if (spear.getItemMeta() instanceof Damageable d) {
                d.setDamage(d.getDamage() + 5);
                spear.setItemMeta(d);
            }
        }
    }
}
