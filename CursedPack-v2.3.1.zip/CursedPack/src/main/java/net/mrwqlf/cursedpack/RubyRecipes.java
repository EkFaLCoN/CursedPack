package net.mrwqlf.cursedpack;

import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Datapack'teki tüm tarifler.
 *
 * Dövme masası (şablon boş, taban netherite eşya, ekleme Ruby Bloğu):
 *     netherite_sword / axe / pickaxe / shovel / hoe   -> Ruby aleti
 *     netherite_helmet / chestplate / leggings / boots -> Ruby zırhı
 * Şablon da Ruby Bloğu ise:
 *     Ruby Bloğu + netherite_axe + Ruby Bloğu          -> Ruby Savaş Baltası
 *
 * Tezgâh:
 *     9x Ruby Tozu -> 1 Ruby         1 Ruby       -> 9 Ruby Tozu
 *     9x Ruby      -> 1 Ruby Bloğu   1 Ruby Bloğu -> 9 Ruby
 *
 * Tariflerin sonucu GERÇEK eşyadır (items.yml önbelleğinden). Önbellek boşsa
 * tarifler kaydedilmez ve konsola "/cursedpack cache" uyarısı düşer.
 */
public final class RubyRecipes implements Listener {

    private final CursedPack plugin;

    static final Map<Material, String> SMITH = new LinkedHashMap<>();
    static {
        SMITH.put(Material.NETHERITE_SWORD, "sword");
        SMITH.put(Material.NETHERITE_AXE, "axe");
        SMITH.put(Material.NETHERITE_PICKAXE, "pickaxe");
        SMITH.put(Material.NETHERITE_SHOVEL, "shovel");
        SMITH.put(Material.NETHERITE_HOE, "hoe");
        SMITH.put(Material.NETHERITE_HELMET, "helmet");
        SMITH.put(Material.NETHERITE_CHESTPLATE, "chestplate");
        SMITH.put(Material.NETHERITE_LEGGINGS, "leggings");
        SMITH.put(Material.NETHERITE_BOOTS, "boots");
    }

    public RubyRecipes(CursedPack plugin) {
        this.plugin = plugin;
    }

    public boolean register() {
        ItemCache cache = plugin.cache();
        if (cache.isEmpty()) {
            plugin.getLogger().warning("Eşya önbelleği boş — tarifler kaydedilmedi.");
            plugin.getLogger().warning("Oyun içinde bir kez '/cursedpack cache' çalıştır.");
            return false;
        }

        unregisterAll();
        int n = 0;

        // ---------------- dövme masası ----------------
        RecipeChoice rubyBlock = choice("ruby_block", Material.QUARTZ_BRICKS);

        for (var en : SMITH.entrySet()) {
            ItemStack result = cache.get(en.getValue());
            if (result == null) continue;
            if (addSmithing("smith_" + en.getValue(), result, null,
                    new RecipeChoice.MaterialChoice(en.getKey()), rubyBlock)) n++;
        }

        ItemStack warAxe = cache.get("war_axe");
        if (warAxe != null && addSmithing("smith_war_axe", warAxe, rubyBlock,
                new RecipeChoice.MaterialChoice(Material.NETHERITE_AXE), rubyBlock)) n++;

        // ---------------- tezgâh ----------------
        ItemStack ruby = cache.get("ruby");
        ItemStack dust = cache.get("ruby_dust");
        ItemStack block = cache.get("ruby_block");

        if (ruby != null && dust != null) {
            ShapedRecipe r1 = new ShapedRecipe(key("dust_to_ruby"), ruby.clone());
            r1.shape("###", "###", "###");
            r1.setIngredient('#', choice("ruby_dust", Material.HEART_OF_THE_SEA));
            if (add(r1)) n++;

            ItemStack dust9 = dust.clone();
            dust9.setAmount(9);
            ShapelessRecipe r2 = new ShapelessRecipe(key("ruby_to_dust"), dust9);
            r2.addIngredient(choice("ruby", Material.ECHO_SHARD));
            if (add(r2)) n++;
        }

        if (ruby != null && block != null) {
            ItemStack ruby9 = ruby.clone();
            ruby9.setAmount(9);
            ShapelessRecipe r3 = new ShapelessRecipe(key("block_to_ruby"), ruby9);
            r3.addIngredient(choice("ruby_block", Material.QUARTZ_BRICKS));
            if (add(r3)) n++;

            ShapedRecipe r4 = new ShapedRecipe(key("ruby_to_block"), block.clone());
            r4.shape("###", "###", "###");
            r4.setIngredient('#', choice("ruby", Material.ECHO_SHARD));
            if (add(r4)) n++;
        }

        plugin.getLogger().info(n + " tarif kaydedildi.");
        for (var p : Bukkit.getOnlinePlayers()) discover(p);
        return n > 0;
    }

    /** Önbellekte gerçek eşya varsa TAM eşleşme — sıradan echo_shard tarifi tetiklemesin. */
    private RecipeChoice choice(String cacheKey, Material fallback) {
        ItemStack proto = plugin.cache().get(cacheKey);
        if (proto != null) {
            try {
                return new RecipeChoice.ExactChoice(proto);
            } catch (Throwable ignored) { }
        }
        return new RecipeChoice.MaterialChoice(fallback);
    }

    private NamespacedKey key(String k) {
        return new NamespacedKey(plugin, k);
    }

    private boolean addSmithing(String k, ItemStack result, RecipeChoice template,
                                RecipeChoice base, RecipeChoice addition) {
        try {
            return add(new SmithingTransformRecipe(key(k), result.clone(), template, base, addition));
        } catch (Throwable t) {
            try {
                return add(new SmithingTransformRecipe(key(k), result.clone(),
                        choice("ruby_block", Material.QUARTZ_BRICKS), base, addition));
            } catch (Throwable t2) {
                plugin.getLogger().warning("Dövme tarifi eklenemedi (" + k + "): " + t2);
                return false;
            }
        }
    }

    private boolean add(Recipe r) {
        try {
            return Bukkit.addRecipe(r);
        } catch (Throwable t) {
            plugin.getLogger().warning("Tarif eklenemedi: " + t.getMessage());
            return false;
        }
    }

    private void unregisterAll() {
        for (String k : allKeys()) {
            try { Bukkit.removeRecipe(key(k)); } catch (Throwable ignored) { }
        }
    }

    private String[] allKeys() {
        return new String[]{
                "dust_to_ruby", "ruby_to_dust", "block_to_ruby", "ruby_to_block",
                "smith_sword", "smith_axe", "smith_pickaxe", "smith_shovel", "smith_hoe",
                "smith_helmet", "smith_chestplate", "smith_leggings", "smith_boots", "smith_war_axe"};
    }

    @EventHandler
    public void onJoin(org.bukkit.event.player.PlayerJoinEvent e) {
        discover(e.getPlayer());
    }

    private void discover(org.bukkit.entity.Player p) {
        for (String k : allKeys()) {
            try { p.discoverRecipe(key(k)); } catch (Throwable ignored) { }
        }
    }

    /** Güvenlik ağı: malzemeler gerçek Ruby değilse sonucu iptal et. */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        Recipe r = e.getRecipe();
        if (!(r instanceof Keyed k)) return;
        if (!k.getKey().getNamespace().equalsIgnoreCase(plugin.getName())) return;

        String needed = switch (k.getKey().getKey()) {
            case "dust_to_ruby" -> "ruby/ruby_dust";
            case "ruby_to_dust", "ruby_to_block" -> "ruby/ruby";
            case "block_to_ruby" -> "ruby/ruby_block";
            default -> null;
        };
        if (needed == null) return;

        for (ItemStack st : e.getInventory().getMatrix()) {
            if (st == null || st.getType().isAir()) continue;
            if (!CursedPack.isModel(st, needed)) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }
}
