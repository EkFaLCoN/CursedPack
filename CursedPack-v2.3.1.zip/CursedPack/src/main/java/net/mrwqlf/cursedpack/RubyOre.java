package net.mrwqlf.cursedpack;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.world.ChunkPopulateEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Random;

/**
 * Nether'da y24-36 arasi Ruby Ore olusumu + kirilinca ozel drop.
 * Datapack'te worldgen feature ile yapiliyordu; burada chunk olusunca Java ile yerlestiriliyor.
 * Ore blogu: deepslate_emerald_ore (resourcepack'te ruby dokusu ile gosteriliyor).
 */
public final class RubyOre implements Listener {

    private static final Material ORE = Material.DEEPSLATE_EMERALD_ORE;
    private final CursedPack plugin;

    public RubyOre(CursedPack plugin) { this.plugin = plugin; }

    @EventHandler
    public void onPopulate(ChunkPopulateEvent e) {
        if (!plugin.getConfig().getBoolean("ruby.ore.generate", true)) return;
        Chunk c = e.getChunk();
        World w = c.getWorld();
        if (w.getEnvironment() != World.Environment.NETHER) return;

        int veins = plugin.getConfig().getInt("ruby.ore.veins-per-chunk", 5);
        int minY = plugin.getConfig().getInt("ruby.ore.min-y", 24);
        int maxY = plugin.getConfig().getInt("ruby.ore.max-y", 36);

        Random r = new Random(w.getSeed() ^ ((long) c.getX() << 32) ^ c.getZ());
        for (int i = 0; i < veins; i++) {
            int x = r.nextInt(16);
            int z = r.nextInt(16);
            int y = minY + r.nextInt(Math.max(1, maxY - minY + 1));
            placeVein(c.getBlock(x, y, z), r);
        }
    }

    /**
     * Ruby Tozu yere DUSER (envantere gitmez).
     * Bilesenleri birebir korumak icin once give ile uretilir, sonra envanterden
     * alinip esya varligi olarak dunyaya birakilir.
     */
    private void dropDust(Player p, org.bukkit.Location where, int count) {
        var inv = p.getInventory();
        ItemStack[] before = new ItemStack[inv.getSize()];
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack st = inv.getItem(i);
            before[i] = st == null ? null : st.clone();
        }

        for (int i = 0; i < count; i++) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    "minecraft:give " + p.getName() + " " + Items.dustSpec());
        }

        // yeni eklenenleri envanterden cikar ve yere birak
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack now = inv.getItem(i);
            if (now == null) continue;
            ItemStack was = before[i];

            int added;
            if (was == null) {
                added = now.getAmount();
            } else if (was.isSimilar(now)) {
                added = now.getAmount() - was.getAmount();
            } else {
                continue;
            }
            if (added <= 0) continue;

            ItemStack drop = now.clone();
            drop.setAmount(added);

            if (was == null) inv.setItem(i, null);
            else inv.setItem(i, was);

            where.getWorld().dropItem(where, drop);
        }
    }

    private void placeVein(Block center, Random r) {
        int size = 2 + r.nextInt(2);
        for (int i = 0; i < size; i++) {
            Block b = center.getRelative(r.nextInt(3) - 1, r.nextInt(3) - 1, r.nextInt(3) - 1);
            if (b.getType() == Material.NETHERRACK || b.getType() == Material.BASALT
                    || b.getType() == Material.BLACKSTONE) {
                b.setType(ORE, false);
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (e.getBlock().getType() != ORE) return;
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();

        if (tool.getEnchantmentLevel(Enchantment.SILK_TOUCH) > 0) return; // blogun kendisi dussun

        e.setDropItems(false);
        int fortune = tool.getEnchantmentLevel(Enchantment.FORTUNE);
        Random r = new Random();

        int count;
        if (fortune >= 3) count = 1 + r.nextInt(2);
        else if (fortune == 2) count = 1;
        else if (fortune == 1) count = r.nextDouble() < 0.9 ? 1 : 0;
        else count = r.nextDouble() < 0.5 ? 1 : 0;

        if (count > 0) {
            dropDust(p, e.getBlock().getLocation().add(0.5, 0.5, 0.5), count);
        }
    }
}
