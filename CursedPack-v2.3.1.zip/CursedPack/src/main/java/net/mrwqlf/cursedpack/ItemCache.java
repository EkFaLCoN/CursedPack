package net.mrwqlf.cursedpack;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Eşya örnekleri (prototip) deposu.
 *
 * Eşyalar vanilla "give" komutuyla üretiliyor; bu yüzden Java tarafında elimizde
 * hazır bir ItemStack yok. Tariflerin SONUCU gerçek eşya olmalı, yoksa tarif
 * kitabında bozuk/mor doku ve yanlış tooltip görünüyor.
 *
 * Çözüm: bir kez "/cursedpack cache" çalıştırılır. Her eşya oyuncuya verilir,
 * ItemStack olarak yakalanır, envanterden alınır ve items.yml'ye yazılır.
 * Sonraki açılışlarda dosyadan okunur ve tarifler gerçek eşya ile kaydedilir.
 */
public final class ItemCache {

    private final CursedPack plugin;
    private final File file;
    private final Map<String, ItemStack> items = new HashMap<>();

    public ItemCache(CursedPack plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "items.yml");
        load();
    }

    public boolean isEmpty() { return items.isEmpty(); }

    public int size() { return items.size(); }

    public ItemStack get(String key) {
        ItemStack st = items.get(key);
        return st == null ? null : st.clone();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            ItemStack st = y.getItemStack(k);
            if (st != null) items.put(k, st);
        }
        plugin.getLogger().info("Eşya önbelleği yüklendi: " + items.size() + " eşya.");
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        items.forEach(y::set);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (Exception e) {
            plugin.getLogger().warning("items.yml yazılamadı: " + e.getMessage());
        }
    }

    /**
     * Tüm eşyaları oyuncuya verip yakalar, envanteri olduğu gibi geri koyar.
     *
     * Vanilla "give" eşyayı seçili hotbar slotundan başlayarak yerleştirir ya da
     * mevcut yığına ekler; bu yüzden tek bir slota bakmak yetmiyor. Tüm envanterin
     * öncesi/sonrası karşılaştırılıyor.
     */
    public int rebuild(Player p) {
        items.clear();
        int ok = 0;

        for (String key : Items.names()) {
            if (key.equals("armor")) continue;   // dört parçayı birden verir, atla
            ItemStack got = capture(p, key);
            if (got == null) {
                plugin.getLogger().warning("Yakalanamadı: " + key);
                continue;
            }
            items.put(key, got);
            ok++;
        }

        save();
        return ok;
    }

    /** Bir eşyayı verip envanter farkından yakalar, sonra envanteri eski haline döndürür. */
    private ItemStack capture(Player p, String key) {
        var inv = p.getInventory();
        int size = inv.getSize();

        ItemStack[] before = new ItemStack[size];
        for (int i = 0; i < size; i++) {
            ItemStack st = inv.getItem(i);
            before[i] = st == null ? null : st.clone();
        }

        if (!Items.give(p, key)) return null;

        ItemStack found = null;
        for (int i = 0; i < size; i++) {
            ItemStack now = inv.getItem(i);
            if (now == null || now.getType().isAir()) continue;
            ItemStack was = before[i];

            boolean isNew = (was == null)
                    || (was.isSimilar(now) && now.getAmount() > was.getAmount())
                    || !was.isSimilar(now);
            if (!isNew) continue;

            found = now.clone();
            found.setAmount(1);
            break;
        }

        // envanteri eski haline getir (verilen eşya kalmasın)
        for (int i = 0; i < size; i++) inv.setItem(i, before[i]);

        return found;
    }

}
