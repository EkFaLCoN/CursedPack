package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Ruby Axe    — Agac Yikici: bagli kutuk+yapraklar. Blok basina 1 dayaniklilik,
 *               Kirilmazlik I/II/III ile 0.75 / 0.5 / 0.25. Yaprakta %1 altin elma,
 *               %0.005 buyulu altin elma. Yapi odunlarina dokunmaz (yakinda dogal yaprak sarti).
 * Ruby Shovel — Kepce: bakis yonune gore 3x3 duzlem.
 * Ruby Hoe    — Toplu Hasat: 5x5 olgun ekin, hasat + yeniden ek.
 * Ruby Pickaxe— Nether'in Gozu: comelince 8 saniye, 16 blok cevredeki madenler parlar.
 *               2 dakika bekleme. Ruby Ore bilerek gorunmez.
 */
public final class RubyTools implements Listener {

    private final CursedPack plugin;
    private final Set<UUID> busy = new HashSet<>();
    private final Random rng = new Random();

    private final Map<UUID, Integer> eyeLeft = new HashMap<>();
    private final Map<UUID, Integer> eyeCd = new HashMap<>();
    private final Map<UUID, List<UUID>> eyeMarks = new HashMap<>();

    public RubyTools(CursedPack plugin) {
        this.plugin = plugin;
        startEyeTicker();
    }

    // ------------------------------------------------------------ blok kirma

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (busy.contains(p.getUniqueId())) return;

        ItemStack hand = p.getInventory().getItemInMainHand();
        String model = CursedPack.modelOf(hand);

        if (model.endsWith("ruby/ruby_axe") && Tag.LOGS.isTagged(e.getBlock().getType())) {
            chopTree(p, e.getBlock(), hand);
        } else if (model.endsWith("ruby/ruby_shovel")) {
            digPlane(p, e.getBlock(), hand);
        } else if (model.endsWith("ruby/ruby_hoe")) {
            harvest(p, e.getBlock(), hand);
        }
    }

    // ------------------------------------------------------------ agac yikici

    private void chopTree(Player p, Block origin, ItemStack tool) {
        // Kapi: yakinda DOGAL yaprak yoksa yapi odunudur, dokunma.
        if (!naturalLeavesNearby(origin)) return;

        int unb = Math.min(3, tool.getEnchantmentLevel(Enchantment.UNBREAKING));
        int mul = Math.max(1, 4 - unb);          // yok=4, I=3, II=2, III=1
        int remaining = durabilityLeft(tool);
        if (remaining <= 0) return;

        int cap = Math.min(900, Math.max(1, remaining * 4 / mul));

        List<Block> logs = new ArrayList<>();
        List<Block> leaves = new ArrayList<>();
        collectTree(origin, cap, logs, leaves);

        int count = logs.size() + leaves.size();
        if (count == 0) return;

        busy.add(p.getUniqueId());
        try {
            for (Block b : logs) b.breakNaturally(tool);
            for (Block b : leaves) {
                Location dropAt = b.getLocation().add(0.5, 0.5, 0.5);
                b.breakNaturally(tool);
                double roll = rng.nextDouble();
                if (roll < 0.00005) {
                    b.getWorld().dropItem(dropAt, new ItemStack(Material.ENCHANTED_GOLDEN_APPLE));
                } else if (roll < 0.01) {
                    b.getWorld().dropItem(dropAt, new ItemStack(Material.GOLDEN_APPLE));
                }
            }
        } finally {
            busy.remove(p.getUniqueId());
        }

        int spent = count * mul / 4;
        p.playSound(p.getLocation(), Sound.BLOCK_WOOD_BREAK, 1f, 0.7f);

        if (spent >= remaining) {
            p.getInventory().setItemInMainHand(null);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
        } else {
            applyDamage(tool, spent);
            p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.4f, 1.4f);
            p.sendActionBar(Component.text()
                    .append(Component.text("AĞAÇ YIKICI", NamedTextColor.GREEN).decorate(TextDecoration.BOLD))
                    .append(Component.text("  " + count + " blok  •  -" + spent + " dayanıklılık",
                            NamedTextColor.GRAY))
                    .build());
        }
    }

    private boolean naturalLeavesNearby(Block origin) {
        for (int dx = -4; dx <= 4; dx++)
            for (int dy = -1; dy <= 6; dy++)
                for (int dz = -4; dz <= 4; dz++) {
                    Block b = origin.getRelative(dx, dy, dz);
                    if (!Tag.LEAVES.isTagged(b.getType())) continue;
                    if (b.getBlockData() instanceof org.bukkit.block.data.type.Leaves lv && !lv.isPersistent()) {
                        return true;
                    }
                }
        return false;
    }

    private void collectTree(Block origin, int cap, List<Block> logs, List<Block> leaves) {
        Deque<Block> queue = new ArrayDeque<>();
        Set<Block> seen = new HashSet<>();
        queue.add(origin);
        seen.add(origin);

        while (!queue.isEmpty() && logs.size() + leaves.size() < cap) {
            Block b = queue.poll();
            boolean isLog = Tag.LOGS.isTagged(b.getType());
            boolean isLeaf = Tag.LEAVES.isTagged(b.getType());
            if (!isLog && !isLeaf) continue;

            if (isLeaf) {
                if (b.getBlockData() instanceof org.bukkit.block.data.type.Leaves lv && lv.isPersistent()) continue;
                leaves.add(b);
                // Yapraktan da yayil — yoksa genis taclı agaclarda dis yapraklar kaliyordu.
                for (int dx = -1; dx <= 1; dx++)
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dz = -1; dz <= 1; dz++) {
                            Block n = b.getRelative(dx, dy, dz);
                            if (Tag.LEAVES.isTagged(n.getType()) || Tag.LOGS.isTagged(n.getType())) {
                                if (seen.add(n)) queue.add(n);
                            }
                        }
                continue;
            }
            logs.add(b);

            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        Block n = b.getRelative(dx, dy, dz);
                        if (seen.add(n)) queue.add(n);
                    }
        }
    }

    // ------------------------------------------------------------ kepce

    private void digPlane(Player p, Block center, ItemStack tool) {
        float pitch = p.getLocation().getPitch();
        float yaw = p.getLocation().getYaw();

        busy.add(p.getUniqueId());
        try {
            for (int a = -1; a <= 1; a++)
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    Block t;
                    if (pitch >= 40 || pitch <= -40) {
                        t = center.getRelative(a, 0, b);              // yatay duzlem
                    } else if (isFacingZ(yaw)) {
                        t = center.getRelative(a, b, 0);              // Z'ye bakiyor
                    } else {
                        t = center.getRelative(0, b, a);              // X'e bakiyor
                    }
                    if (!Tag.MINEABLE_SHOVEL.isTagged(t.getType())) continue;
                    t.breakNaturally(tool);
                    applyDamage(tool, 1);
                }
        } finally {
            busy.remove(p.getUniqueId());
        }
    }

    private boolean isFacingZ(float yaw) {
        float y = ((yaw % 360) + 360) % 360;
        return (y >= 315 || y < 45) || (y >= 135 && y < 225);
    }

    // ------------------------------------------------------------ toplu hasat

    private void harvest(Player p, Block center, ItemStack tool) {
        if (!(center.getBlockData() instanceof Ageable ag) || ag.getAge() < ag.getMaximumAge()) return;

        busy.add(p.getUniqueId());
        int n = 0;
        try {
            for (int dx = -2; dx <= 2; dx++)
                for (int dz = -2; dz <= 2; dz++) {
                    Block b = center.getRelative(dx, 0, dz);
                    if (!(b.getBlockData() instanceof Ageable a2)) continue;
                    if (a2.getAge() < a2.getMaximumAge()) continue;
                    if (!isCrop(b.getType())) continue;

                    Material type = b.getType();
                    b.breakNaturally(tool);
                    b.setType(type, false);
                    if (b.getBlockData() instanceof Ageable fresh) {
                        fresh.setAge(0);
                        b.setBlockData(fresh, false);
                    }
                    applyDamage(tool, 1);
                    n++;
                }
        } finally {
            busy.remove(p.getUniqueId());
        }
        if (n > 0) {
            p.playSound(p.getLocation(), Sound.ITEM_CROP_PLANT, 1f, 1.2f);
            p.sendActionBar(Component.text()
                    .append(Component.text("TOPLU HASAT", NamedTextColor.GREEN).decorate(TextDecoration.BOLD))
                    .append(Component.text("  " + n + " ekin", NamedTextColor.GRAY))
                    .build());
        }
    }

    private boolean isCrop(Material m) {
        return m == Material.WHEAT || m == Material.CARROTS || m == Material.POTATOES
                || m == Material.BEETROOTS || m == Material.NETHER_WART;
    }

    // ------------------------------------------------------------ nether'in gozu

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (!e.isSneaking()) return;
        Player p = e.getPlayer();
        if (!CursedPack.isModel(p.getInventory().getItemInMainHand(), "ruby/ruby_pickaxe")) return;

        UUID id = p.getUniqueId();
        if (eyeLeft.containsKey(id)) return;

        int cd = eyeCd.getOrDefault(id, 0);
        if (cd > 0) {
            p.sendActionBar(Component.text("Nether'in Gözü: " + ((cd + 19) / 20) + " sn",
                    NamedTextColor.GRAY));
            return;
        }

        eyeLeft.put(id, 160);   // 8 saniye
        eyeCd.put(id, 2400);    // 2 dakika
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.6f, 1.8f);
        scanOres(p);
    }

    private void scanOres(Player p) {
        List<UUID> marks = new ArrayList<>();
        Location base = p.getLocation();

        for (int dx = -8; dx <= 8; dx++)
            for (int dy = -8; dy <= 8; dy++)
                for (int dz = -8; dz <= 8; dz++) {
                    Block b = base.clone().add(dx, dy, dz).getBlock();
                    Integer color = oreColor(b.getType());
                    if (color == null) continue;

                    BlockDisplay bd = b.getWorld().spawn(b.getLocation(), BlockDisplay.class, d -> {
                        d.setBlock(Material.GLASS.createBlockData());
                        d.setGlowing(true);
                        d.setGlowColorOverride(Color.fromRGB(color));
                        d.setPersistent(false);
                    });
                    marks.add(bd.getUniqueId());
                }

        eyeMarks.put(p.getUniqueId(), marks);
        p.sendActionBar(Component.text()
                .append(Component.text("NETHER'İN GÖZÜ", NamedTextColor.AQUA).decorate(TextDecoration.BOLD))
                .append(Component.text("  " + marks.size() + " maden", NamedTextColor.GRAY))
                .build());
    }

    /** Her maden kendi renginde. Ruby Ore (deepslate_emerald_ore) BILEREK yok. */
    private Integer oreColor(Material m) {
        return switch (m) {
            case DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE -> 58879;
            case GOLD_ORE, DEEPSLATE_GOLD_ORE, NETHER_GOLD_ORE -> 16765488;
            case EMERALD_ORE -> 2284885;
            case LAPIS_ORE, DEEPSLATE_LAPIS_ORE -> 3364351;
            case REDSTONE_ORE, DEEPSLATE_REDSTONE_ORE -> 11141120;
            case IRON_ORE, DEEPSLATE_IRON_ORE -> 14729376;
            case COPPER_ORE, DEEPSLATE_COPPER_ORE -> 16742195;
            case COAL_ORE, DEEPSLATE_COAL_ORE -> 5592405;
            case NETHER_QUARTZ_ORE -> 16777215;
            case ANCIENT_DEBRIS -> 11567359;
            default -> null;
        };
    }

    private void startEyeTicker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                eyeCd.replaceAll((k, v) -> Math.max(0, v - 1));

                Iterator<Map.Entry<UUID, Integer>> it = eyeLeft.entrySet().iterator();
                while (it.hasNext()) {
                    var en = it.next();
                    int left = en.getValue() - 1;
                    if (left > 0) { en.setValue(left); continue; }

                    it.remove();
                    clearMarks(en.getKey());
                    Player p = plugin.getServer().getPlayer(en.getKey());
                    if (p != null) {
                        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 0.4f, 1.8f);
                        p.sendActionBar(Component.text(""));
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void clearMarks(UUID id) {
        List<UUID> marks = eyeMarks.remove(id);
        if (marks == null) return;
        for (UUID m : marks) {
            var ent = plugin.getServer().getEntity(m);
            if (ent != null) ent.remove();
        }
    }

    // ------------------------------------------------------------ yardimci

    static int durabilityLeft(ItemStack tool) {
        if (!(tool.getItemMeta() instanceof Damageable d)) return Integer.MAX_VALUE;
        return tool.getType().getMaxDurability() - d.getDamage();
    }

    static void applyDamage(ItemStack tool, int amount) {
        if (amount <= 0) return;
        if (tool.getItemMeta() instanceof Damageable d) {
            d.setDamage(d.getDamage() + amount);
            tool.setItemMeta(d);
        }
    }
}
