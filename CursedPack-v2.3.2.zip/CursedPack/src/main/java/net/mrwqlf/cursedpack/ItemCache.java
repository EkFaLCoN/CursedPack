package net.mrwqlf.cursedpack;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Eşya örnekleri (prototip) deposu.
 *
 * Eşyalar vanilla "give" komutuyla üretiliyor; bu yüzden Java tarafında elimizde
 * hazır bir ItemStack yok. Tariflerin SONUCU gerçek eşya olmalı, yoksa tarif
 * kitabında bozuk/mor doku ve yanlış tooltip görünüyor.
 *
 * Çözüm: bir kez "/cursedpack cache" çalıştırılır. Her eşya oyuncuya verilir,
 * ItemStack olarak yakalanır, envanterden alınır ve items.yml'ye yazılır.
 * Sonraki açılışlarda dosyadan okunur ve tarifler gerçek eşya ile kaydedilir.
 */
public final class ItemCache {

    private final CursedPack plugin;
    private final File file;
    private final Map<String, ItemStack> items = new HashMap<>();

    public ItemCache(CursedPack plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "items.yml");
        load();
    }

    public boolean isEmpty() { return items.isEmpty(); }

    public int size() { return items.size(); }

    public ItemStack get(String key) {
        ItemStack st = items.get(key);
        return st == null ? null : st.clone();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            ItemStack st = y.getItemStack(k);
            if (st != null) items.put(k, st);
        }
        plugin.getLogger().info("Eşya önbelleği yüklendi: " + items.size() + " eşya.");
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        items.forEach(y::set);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (Exception e) {
            plugin.getLogger().warning("items.yml yazılamadı: " + e.getMessage());
        }
    }

    /**
     * Tüm eşyaları sırayla verip yakalar.
     *
     * ÖNEMLİ: "give" komutu aynı tik içinde envantere yansımıyor. Bu yüzden
     * her eşya için: (1) envanter kopyası al + give çalıştır, (2) BİR SONRAKİ
     * TİKTE farkı oku ve envanteri geri koy. Aynı tikte okumaya çalışmak
     * hiçbir şey yakalayamıyordu.
     */
    public void rebuild(Player p, java.util.function.IntConsumer done) {
        items.clear();
        java.util.List<String> keys = new java.util.ArrayList<>(Items.names());
        keys.remove("armor");   // dört parçayı birden verir, tek eşya değil

        new org.bukkit.scheduler.BukkitRunnable() {
            int index = 0;
            int ok = 0;
            boolean waiting = false;
            ItemStack[] before;
            String current;

            @Override
            public void run() {
                if (!p.isOnline()) { cancel(); return; }
                var inv = p.getInventory();

                if (!waiting) {
                    if (index >= keys.size()) {
                        save();
                        plugin.getLogger().info("Önbellek yenilendi: " + ok + " eşya.");
                        done.accept(ok);
                        cancel();
                        return;
                    }
                    current = keys.get(index);

                    before = new ItemStack[inv.getSize()];
                    for (int i = 0; i < inv.getSize(); i++) {
                        ItemStack st = inv.getItem(i);
                        before[i] = st == null ? null : st.clone();
                    }

                    if (!Items.give(p, current)) {
                        plugin.getLogger().warning("give başarısız: " + current);
                        index++;
                        return;
                    }
                    waiting = true;   // fark bir sonraki tikte okunacak
                    return;
                }

                // --- bir tik sonrası: farkı oku ---
                ItemStack found = null;
                for (int i = 0; i < inv.getSize(); i++) {
                    ItemStack now = inv.getItem(i);
                    if (now == null || now.getType().isAir()) continue;
                    ItemStack was = before[i];

                    boolean isNew = (was == null)
                            || !was.isSimilar(now)
                            || now.getAmount() > was.getAmount();
                    if (!isNew) continue;

                    found = now.clone();
                    found.setAmount(1);
                    break;
                }

                if (found != null) {
                    items.put(current, found);
                    ok++;
                } else {
                    plugin.getLogger().warning("Yakalanamadı: " + current);
                }

                // envanteri eski haline döndür
                for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, before[i]);

                index++;
                waiting = false;
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

}
