package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.*;

/**
 * War Scythe — datapack davranisinin birebir karsiligi.
 *
 * Sag tik    : tirpan elden cikar, bakis yonunde tik basina 0.5 blok = 10 blok ucar
 * Degdiginde : hedef sahibin yanina isinlanir
 *              %90 -> 3 saniye yere sabitlenir
 *              %10 -> sabitleme tutmaz
 * 20 tick sonra silah ele geri doner ve sonuc mesaji yazilir
 * Cooldown   : 60 saniye
 * Her firlatma 5 dayaniklilik goturur
 */
public final class WarScythe implements Listener {

    private static final String MODEL = "warscythe/warscythe";
    private static final int COOLDOWN_TICKS = 1200;
    private static final int FLIGHT_TICKS = 20;
    private static final int ROOT_TICKS = 60;
    private static final int ROOT_CHANCE = 90;
    private static final int DURABILITY_COST = 5;

    private final CursedPack plugin;

    private final Map<UUID, Integer> cooldown = new HashMap<>();
    private final Map<UUID, ItemStack> vault = new HashMap<>();
    private final Map<UUID, Integer> returnIn = new HashMap<>();
    private final Map<UUID, Integer> result = new HashMap<>();
    private final Map<UUID, Location> rootAnchor = new HashMap<>();
    private final Map<UUID, Integer> rootLeft = new HashMap<>();

    public WarScythe(CursedPack plugin) {
        this.plugin = plugin;
        startTicker();
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        if (!CursedPack.isModel(p.getInventory().getItemInMainHand(), MODEL)) return;
        e.setCancelled(true);

        if (cooldown.getOrDefault(p.getUniqueId(), 0) > 0) { deny(p); return; }
        if (returnIn.containsKey(p.getUniqueId())) return;

        throwScythe(p);
    }

    private void deny(Player p) {
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.5f);
        p.sendActionBar(Component.text()
                .append(Component.text("War Scythe ", NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD))
                .append(Component.text("henüz hazır değil!", NamedTextColor.RED))
                .build());
    }

    private void throwScythe(Player p) {
        UUID id = p.getUniqueId();
        ItemStack held = p.getInventory().getItemInMainHand();
        ItemStack copy = held.clone();
        copy.setAmount(1);

        if (p.getGameMode() != GameMode.CREATIVE && copy.getItemMeta() instanceof Damageable d) {
            int nd = d.getDamage() + DURABILITY_COST;
            if (nd >= copy.getType().getMaxDurability()) {
                p.getInventory().setItemInMainHand(null);
                p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
                return;
            }
            d.setDamage(nd);
            copy.setItemMeta(d);
        }

        vault.put(id, copy);
        returnIn.put(id, FLIGHT_TICKS + 1);
        result.put(id, 0);
        cooldown.put(id, COOLDOWN_TICKS);

        if (p.getGameMode() != GameMode.CREATIVE) p.getInventory().setItemInMainHand(null);

        spawnProjectile(p, copy);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.7f);
    }

    private void spawnProjectile(Player owner, ItemStack visual) {
        // Yon bir kez alinir, ucus boyunca DEGISMEZ.
        // YATAY ucus: bakis asagi/yukari olsa da tirpan duz gider (Y bileseni sifirlanir).
        Vector flat = owner.getEyeLocation().getDirection();
        flat.setY(0);
        if (flat.lengthSquared() < 0.0001) flat = new Vector(0, 0, 1);
        final Vector step = flat.normalize().multiply(0.5);
        final float yaw = owner.getLocation().getYaw();
        final float pitch = 0f;   // tirpan yere paralel dursun

        // omuz hizasindan cikar, ucus boyunca ayni yukseklikte kalir
        Location start = owner.getLocation().clone().add(0, 1.2, 0).add(step.clone().multiply(1.6));
        start.setYaw(yaw);
        start.setPitch(pitch);

        ItemDisplay disp = owner.getWorld().spawn(start, ItemDisplay.class, d -> {
            ItemStack shown = visual.clone();
            shown.setAmount(1);
            d.setItemStack(shown);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setInterpolationDuration(1);
            d.setTeleportDuration(1);
            Transformation t = d.getTransformation();
            t.getScale().set(1.6f, 1.6f, 1.6f);
            d.setTransformation(t);
        });

        final Set<UUID> hitOnce = new HashSet<>();

        new BukkitRunnable() {
            int life = FLIGHT_TICKS;
            float spin = 0f;

            @Override
            public void run() {
                if (!disp.isValid() || life-- <= 0) {
                    if (disp.isValid()) {
                        disp.getWorld().spawnParticle(Particle.SWEEP_ATTACK, disp.getLocation(), 1);
                        disp.remove();
                    }
                    cancel();
                    return;
                }

                Location loc = disp.getLocation().clone().add(step);
                loc.setYaw(yaw);
                loc.setPitch(pitch);
                disp.teleport(loc);

                spin += 25f;
                if (spin >= 360f) spin -= 360f;
                Transformation t = disp.getTransformation();
                t.getLeftRotation().set(new AxisAngle4f((float) Math.toRadians(spin),
                        new Vector3f(0f, 0f, 1f)));
                disp.setTransformation(t);

                loc.getWorld().spawnParticle(Particle.CRIT, loc, 3, 0.1, 0.1, 0.1, 0.02);
                loc.getWorld().spawnParticle(Particle.ENCHANTED_HIT, loc, 1, 0, 0, 0, 0);

                for (Entity ent : loc.getWorld().getNearbyEntities(loc, 2.5, 2.5, 2.5)) {
                    if (!(ent instanceof LivingEntity le)) continue;
                    if (le.equals(owner) || isIgnored(le)) continue;
                    if (!hitOnce.add(le.getUniqueId())) continue;
                    pull(owner, le);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void pull(Player owner, LivingEntity target) {
        UUID oid = owner.getUniqueId();
        if (result.getOrDefault(oid, 0) != 1) result.put(oid, 2);

        Location dest = owner.getLocation().clone();
        dest.setYaw(target.getLocation().getYaw());
        dest.setPitch(target.getLocation().getPitch());
        target.teleport(dest);

        target.getWorld().spawnParticle(Particle.PORTAL, target.getLocation().add(0, 1, 0),
                25, 0.4, 0.6, 0.4, 0.1);
        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.8f);

        if (new Random().nextInt(100) < ROOT_CHANCE) {
            rootAnchor.put(target.getUniqueId(), target.getLocation().clone());
            rootLeft.put(target.getUniqueId(), ROOT_TICKS);
            target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST,
                    ROOT_TICKS + 5, 128, true, false, false));

            // sabitlendigini gosteren acilis efekti
            Location f = target.getLocation();
            f.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, f.clone().add(0, 0.1, 0),
                    40, 0.5, 0.1, 0.5, 0.02);
            f.getWorld().spawnParticle(Particle.DUST, f.clone().add(0, 1.0, 0), 30, 0.4, 0.8, 0.4,
                    new Particle.DustOptions(org.bukkit.Color.fromRGB(90, 0, 0), 1.6f));
            f.getWorld().playSound(f, Sound.BLOCK_CHAIN_PLACE, 1.6f, 0.5f);
            f.getWorld().playSound(f, Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 0.9f, 1.6f);

            if (target instanceof Player tp) {
                tp.sendActionBar(Component.text("SABİTLENDİN!", NamedTextColor.DARK_RED)
                        .decorate(TextDecoration.BOLD));
            }
            result.put(oid, 1);
        } else {
            target.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                    target.getLocation().add(0, 1, 0), 12, 0.3, 0.5, 0.3, 0.02);
            target.getWorld().playSound(target.getLocation(), Sound.BLOCK_CHAIN_BREAK, 0.8f, 0.6f);
            owner.sendActionBar(Component.text()
                    .append(Component.text("War Scythe ", NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD))
                    .append(Component.text("Sabitleme tutmadı!", NamedTextColor.RED))
                    .build());
            if (target instanceof Player tp) {
                tp.sendActionBar(Component.text("Zincirlerden kurtuldun!", NamedTextColor.GREEN)
                        .decorate(TextDecoration.BOLD));
            }
        }
    }

    private void startTicker() {
        new BukkitRunnable() {
            @Override public void run() { tickCooldowns(); tickReturns(); tickRoots(); }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void tickCooldowns() {
        Iterator<Map.Entry<UUID, Integer>> it = cooldown.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            Player p = plugin.getServer().getPlayer(en.getKey());
            int left = en.getValue() - 1;
            if (left <= 0) {
                it.remove();
                if (p != null) {
                    p.sendActionBar(Component.text("War Scythe hazır!", NamedTextColor.GREEN)
                            .decorate(TextDecoration.BOLD));
                    p.sendMessage(prefix().append(Component.text(
                            "Yeteneğin hazır! Tekrar kullanabilirsin.", NamedTextColor.GREEN)));
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
                }
                continue;
            }
            en.setValue(left);
            if (p == null) continue;

            boolean holding = CursedPack.isModel(p.getInventory().getItemInMainHand(), MODEL);
            if (holding || returnIn.containsKey(p.getUniqueId())) {
                int sec = (left + 19) / 20;
                p.sendActionBar(Component.text()
                        .append(Component.text("War Scythe ", NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD))
                        .append(Component.text(String.valueOf(sec), NamedTextColor.YELLOW))
                        .append(Component.text(" sn", NamedTextColor.GRAY))
                        .build());
            }
        }
    }

    private void tickReturns() {
        Iterator<Map.Entry<UUID, Integer>> it = returnIn.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            int left = en.getValue() - 1;
            if (left > 0) { en.setValue(left); continue; }

            it.remove();
            UUID id = en.getKey();
            Player p = plugin.getServer().getPlayer(id);
            ItemStack back = vault.remove(id);
            Integer res = result.remove(id);
            if (p == null) continue;

            int r = res == null ? 0 : res;
            if (r == 1) {
                p.sendMessage(prefix().append(Component.text("Yeteneğin Sabitlemesi Başarılı",
                        NamedTextColor.GREEN).decorate(TextDecoration.BOLD)));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1.5f);
            } else if (r == 2) {
                p.sendMessage(prefix().append(Component.text("Yeteneğin Sabitlemesi Başarısız",
                        NamedTextColor.RED).decorate(TextDecoration.BOLD)));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.6f);
            } else {
                p.sendMessage(prefix().append(Component.text("Yetenek Iskalandı",
                        NamedTextColor.GRAY).decorate(TextDecoration.BOLD)));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f, 0.8f);
            }

            if (back != null && p.getGameMode() != GameMode.CREATIVE) {
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand == null || hand.getType().isAir()) {
                    p.getInventory().setItemInMainHand(back);
                } else {
                    p.getInventory().addItem(back).values()
                            .forEach(rest -> p.getWorld().dropItemNaturally(p.getLocation(), rest));
                }
                p.playSound(p.getLocation(), Sound.ITEM_TRIDENT_RETURN, 0.8f, 1.4f);
            }
        }
    }

    private void tickRoots() {
        Iterator<Map.Entry<UUID, Integer>> it = rootLeft.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            UUID id = en.getKey();
            Entity ent = plugin.getServer().getEntity(id);

            if (!(ent instanceof LivingEntity le) || !le.isValid()) {
                it.remove(); rootAnchor.remove(id); continue;
            }
            int left = en.getValue() - 1;
            if (left <= 0) {
                it.remove(); rootAnchor.remove(id);
                le.getWorld().spawnParticle(Particle.SMOKE, le.getLocation().add(0, 0.6, 0),
                        10, 0.3, 0.4, 0.3, 0.02);
                le.getWorld().playSound(le.getLocation(), Sound.BLOCK_CHAIN_BREAK, 0.7f, 1.4f);
                continue;
            }
            en.setValue(left);

            Location anchor = rootAnchor.get(id);
            if (anchor == null) continue;
            Location back = anchor.clone();
            back.setYaw(le.getLocation().getYaw());
            back.setPitch(le.getLocation().getPitch());
            if (le.getLocation().distanceSquared(back) > 0.0001) le.teleport(back);
            le.setVelocity(new Vector(0, 0, 0));
            // ayak dibinde donen zincir halkasi — uzaktan da net gorunur
            Location base = le.getLocation();
            double angle = (ROOT_TICKS - left) * 0.35;
            for (int i = 0; i < 6; i++) {
                double a = angle + i * (Math.PI * 2 / 6);
                Location ring = base.clone().add(Math.cos(a) * 0.85, 0.15, Math.sin(a) * 0.85);
                base.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, ring, 1, 0, 0, 0, 0);
                base.getWorld().spawnParticle(Particle.DUST, ring.clone().add(0, 0.5, 0), 1, 0, 0, 0,
                        new Particle.DustOptions(org.bukkit.Color.fromRGB(120, 0, 0), 1.2f));
            }
            base.getWorld().spawnParticle(Particle.SOUL, base.clone().add(0, 0.9, 0),
                    3, 0.35, 0.5, 0.35, 0.005);
            if (left % 10 == 0) {
                base.getWorld().playSound(base, Sound.BLOCK_CHAIN_STEP, 0.6f, 0.6f);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        ItemStack back = vault.remove(id);
        if (back != null) e.getPlayer().getInventory().addItem(back);
        returnIn.remove(id);
        result.remove(id);
        rootLeft.remove(id);
        rootAnchor.remove(id);
    }

    static Component prefix() {
        return Component.text()
                .append(Component.text("[", NamedTextColor.DARK_GRAY))
                .append(Component.text("War Scythe", NamedTextColor.DARK_RED).decorate(TextDecoration.BOLD))
                .append(Component.text("] ", NamedTextColor.DARK_GRAY))
                .build();
    }

    /** warscythe:ignore etiketi — bunlara dokunulmaz. */
    static boolean isIgnored(LivingEntity le) {
        return switch (le.getType()) {
            case ARMOR_STAND, VILLAGER, WANDERING_TRADER, CAT, WOLF, OCELOT,
                 PIG, CHICKEN, COW, SHEEP, MOOSHROOM, HAPPY_GHAST,
                 HORSE, DONKEY, MULE, SKELETON_HORSE, ZOMBIE_HORSE, CAMEL,
                 LLAMA, TRADER_LLAMA, ENDER_DRAGON, WITHER -> true;
            default -> false;
        };
    }
}
