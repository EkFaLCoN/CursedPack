package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Ruby Sword — Yasam Calma + Kizil Ofke
 *   Her vurusta %50 ihtimalle havuza 22 birim eklenir (1 birim = 0.1 can, tavan 80).
 *   Havuz 40+ ve can 16'nin altindaysa Aninda Iyilesme I verilir, havuzdan 40 duser.
 *   Can 8'in altina dusunce Kizil Ofke: +3 hasar. Can 9+ olunca soner.
 *
 * Ruby War Axe — Kizil Infaz
 *   Hedefin cani %25 veya altina dustugunde isaretlenir (balta kizila keser).
 *   Isaretli hedefe atilan SONRAKI darbe infaz eder: 1000 hasar, player_attack
 *   olarak verilir — boylece rakip Olumsuzluk Totemi'ni kullanabilir.
 */
public final class RubyWeapons implements Listener {

    private final CursedPack plugin;
    private final NamespacedKey rageKey;

    private final Map<UUID, Integer> pool = new HashMap<>();   // yasam calma havuzu (0-80)
    private final Set<UUID> rage = new HashSet<>();            // kizil ofke acik mi
    private final Set<UUID> marked = new HashSet<>();          // infaza isaretli hedefler
    private final Random rng = new Random();

    public RubyWeapons(CursedPack plugin) {
        this.plugin = plugin;
        this.rageKey = new NamespacedKey(plugin, "rage");
        startTicker();
    }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof LivingEntity target)) return;

        String model = CursedPack.modelOf(p.getInventory().getItemInMainHand());

        if (model.endsWith("ruby/ruby_sword")) {
            // %50 ihtimalle yasam cal
            if (rng.nextInt(100) < 50) {
                int v = Math.min(80, pool.getOrDefault(p.getUniqueId(), 0) + 22);
                pool.put(p.getUniqueId(), v);
                p.spawnParticle(Particle.CRIMSON_SPORE, p.getLocation().add(0, 1, 0),
                        8, 0.35, 0.5, 0.35, 0);
                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.35f, 1.7f);
            }
        } else if (model.endsWith("ruby/ruby_war_axe")) {
            if (marked.remove(target.getUniqueId())) {
                // INFAZ — kill degil damage, totem calissin
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.7f);
                p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.35f, 1.8f);
                p.sendActionBar(Component.text("İNFAZ", NamedTextColor.DARK_RED)
                        .decorate(TextDecoration.BOLD));
                e.setDamage(1000.0);
                return;
            }
            // bu darbeden sonra %25 altina dusuyorsa isaretle
            double max = maxHealth(target);
            double after = target.getHealth() - e.getFinalDamage();
            if (after > 0 && max > 0 && after <= max * 0.25) {
                marked.add(target.getUniqueId());
                target.getWorld().spawnParticle(Particle.CRIMSON_SPORE,
                        target.getLocation().add(0, 1, 0), 15, 0.4, 0.6, 0.4, 0);
                target.getWorld().spawnParticle(Particle.DUST, target.getLocation().add(0, 1, 0),
                        12, 0.4, 0.6, 0.4, new Particle.DustOptions(
                                org.bukkit.Color.fromRGB(255, 25, 51), 1.4f));
                p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.7f, 0.6f);
            }
        }
    }

    private void startTicker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player p : plugin.getServer().getOnlinePlayers()) {
                    UUID id = p.getUniqueId();
                    double hp = p.getHealth();

                    // --- Yasam Calma: havuz 40+ ve can 16'nin altinda ---
                    boolean holding = CursedPack.isModel(
                            p.getInventory().getItemInMainHand(), "ruby/ruby_sword");

                    int v = pool.getOrDefault(id, 0);
                    if (v >= 40 && hp <= 16.0 && holding) {
                        pool.put(id, v - 40);
                        p.addPotionEffect(new PotionEffect(PotionEffectType.INSTANT_HEALTH, 1, 0, true, false, false));
                        p.spawnParticle(Particle.HEART, p.getLocation().add(0, 1.2, 0), 3, 0.3, 0.3, 0.3, 0);
                        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.6f, 1.5f);
                    }

                    // --- Kizil Ofke ---
                    // Kizil Ofke SADECE Ruby Sword elde tutulurken baslar.
                    if (hp <= 8.0 && holding && !rage.contains(id)) {
                        rageStart(p);
                    } else if ((hp >= 9.0 || !holding) && rage.contains(id)) {
                        rageEnd(p, holding);
                    }

                    if (rage.contains(id)) {
                        if (holding) {
                            addRageModifier(p);
                            if (rng.nextInt(100) < 30) {
                                p.spawnParticle(Particle.CRIMSON_SPORE, p.getLocation().add(0, 1, 0),
                                        3, 0.3, 0.6, 0.3, 0);
                            }
                        } else {
                            removeRageModifier(p);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 1L);
    }

    private void rageStart(Player p) {
        rage.add(p.getUniqueId());
        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.3f, 1.9f);
        p.spawnParticle(Particle.CRIMSON_SPORE, p.getLocation().add(0, 1, 0), 25, 0.5, 0.8, 0.5, 0);
    }

    private void rageEnd(Player p, boolean holding) {
        rage.remove(p.getUniqueId());
        removeRageModifier(p);
        // Yazi da SADECE kilic eldeyken gorunur.
        if (holding) {
            p.sendActionBar(Component.text("Kızıl Öfke söndü", NamedTextColor.DARK_GRAY));
        }
    }

    private void addRageModifier(Player p) {
        var attr = p.getAttribute(Attribute.ATTACK_DAMAGE);
        if (attr == null || attr.getModifier(rageKey) != null) return;
        attr.addModifier(new AttributeModifier(rageKey, 3.0, AttributeModifier.Operation.ADD_NUMBER));
        p.sendActionBar(Component.text()
                .append(Component.text("KIZIL ÖFKE", NamedTextColor.RED).decorate(TextDecoration.BOLD))
                .append(Component.text("  +3 hasar", NamedTextColor.GRAY))
                .build());
    }

    private void removeRageModifier(Player p) {
        var attr = p.getAttribute(Attribute.ATTACK_DAMAGE);
        if (attr == null) return;
        var mod = attr.getModifier(rageKey);
        if (mod != null) attr.removeModifier(mod);
    }

    static double maxHealth(LivingEntity le) {
        var attr = le.getAttribute(Attribute.MAX_HEALTH);
        return attr == null ? 20.0 : attr.getValue();
    }
}
