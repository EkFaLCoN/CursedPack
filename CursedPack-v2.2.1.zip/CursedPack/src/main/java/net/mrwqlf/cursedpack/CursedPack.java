package net.mrwqlf.cursedpack;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public final class CursedPack extends JavaPlugin implements TabCompleter {

    private static CursedPack instance;
    private ValleyBuilder valley;

    public static CursedPack get() { return instance; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        valley = new ValleyBuilder(this);

        Bukkit.getPluginManager().registerEvents(new WarScythe(this), this);
        Bukkit.getPluginManager().registerEvents(new AdaletCekici(this), this);
        Bukkit.getPluginManager().registerEvents(new RubyWeapons(this), this);
        Bukkit.getPluginManager().registerEvents(new RubyTools(this), this);
        Bukkit.getPluginManager().registerEvents(new RubyArmor(this), this);
        Bukkit.getPluginManager().registerEvents(new RubyOre(this), this);
        Bukkit.getPluginManager().registerEvents(new RubyRecipes(this), this);

        var c = getCommand("cursedpack");
        if (c != null) c.setTabCompleter(this);

        getLogger().info("CursedPack etkin — datapack yok, tüm yetenekler Java.");
    }

    /** item_model anahtarina gore esya kimligi. Datapack'teki custom_data yerine bunu kullaniyoruz. */
    public static String modelOf(ItemStack st) {
        if (st == null || !st.hasItemMeta()) return "";
        try {
            NamespacedKey k = st.getItemMeta().getItemModel();
            return k == null ? "" : k.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    public static boolean isModel(ItemStack st, String suffix) {
        return modelOf(st).endsWith(suffix);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage("§6CursedPack §7— /cursedpack <give|list|valley|info>");
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "give" -> {
                if (a.length < 2) {
                    s.sendMessage("§cKullanım: /cursedpack give <eşya> [oyuncu]");
                    s.sendMessage("§7Eşyalar: §f" + String.join(", ", Items.names()));
                    return true;
                }
                Player t;
                if (a.length >= 3) {
                    t = Bukkit.getPlayerExact(a[2]);
                    if (t == null) { s.sendMessage("§cOyuncu bulunamadı: " + a[2]); return true; }
                } else if (s instanceof Player p) {
                    t = p;
                } else { s.sendMessage("§cKonsoldan oyuncu adı yazmalısın."); return true; }

                if (!Items.give(t, a[1].toLowerCase())) {
                    s.sendMessage("§cBöyle bir eşya yok. §7/cursedpack list");
                    return true;
                }
                s.sendMessage("§a" + a[1].toLowerCase() + " §7-> §f" + t.getName());
                if (!t.equals(s)) t.sendMessage("§aBir eşya aldın: §f" + a[1].toLowerCase());
            }
            case "list" -> s.sendMessage("§6Eşyalar: §f" + String.join(", ", Items.names()));
            case "valley" -> valley.handle(s, a);
            case "info" -> {
                s.sendMessage("§6CursedPack §7v" + getPluginMeta().getVersion());
                s.sendMessage("§7Adalet Çekici · War Scythe · Ruby seti · Cursed Valley");
                s.sendMessage("§7Datapack kullanmıyor — tüm yetenekler Java tarafında.");
            }
            default -> s.sendMessage("§cBilinmeyen alt komut.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("give", "list", "valley", "info"))
                if (x.startsWith(a[0].toLowerCase())) out.add(x);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("give")) {
            for (String k : Items.names()) if (k.startsWith(a[1].toLowerCase())) out.add(k);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("valley")) {
            for (String x : List.of("prep", "build", "status", "stop", "finish"))
                if (x.startsWith(a[1].toLowerCase())) out.add(x);
        } else if (a.length == 3 && a[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers())
                if (p.getName().toLowerCase().startsWith(a[2].toLowerCase())) out.add(p.getName());
        }
        return out;
    }
}
