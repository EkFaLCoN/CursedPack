package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Ruby Sword : %50 ihtimalle hasarin %20'si can calar. Can 8'in altindaysa +3 hasar.
 * Ruby War Axe: hedefin cani %25 veya altindaysa sonraki darbe infaz eder.
 */
public final class RubyWeapons implements Listener {

    private final CursedPack plugin;

    public RubyWeapons(CursedPack plugin) { this.plugin = plugin; }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof LivingEntity target)) return;

        ItemStack hand = p.getInventory().getItemInMainHand();
        String model = CursedPack.modelOf(hand);

        if (model.endsWith("ruby/ruby_sword")) {
            // Kizil Ofke
            if (p.getHealth() < 8.0) {
                e.setDamage(e.getDamage() + 3.0);
                p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 8, 0.3, 0.4, 0.3, 0.01);
            }
            // Yasam Calma
            if (ThreadLocalRandom.current().nextInt(100) < 50) {
                double heal = e.getFinalDamage() * 0.20;
                double max = maxHealth(p);
                p.setHealth(Math.min(max, p.getHealth() + heal));
                p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 2, 0), 1);
                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.6f, 1.6f);
            }
        } else if (model.endsWith("ruby/ruby_war_axe")) {
            double maxT = maxHealth(target);
            double after = target.getHealth() - e.getFinalDamage();

            if (target.hasMetadata("cp_marked")) {
                target.removeMetadata("cp_marked", plugin);
                e.setDamage(e.getDamage() + maxT); // infaz
                target.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 40, 0.4, 0.6, 0.4, 0.4);
                target.getWorld().playSound(target.getLocation(), Sound.ENTITY_WITHER_HURT, 1.2f, 1.4f);
                p.sendActionBar(Component.text("INFAZ!", NamedTextColor.DARK_RED));
            } else if (after > 0 && after <= maxT * 0.25) {
                target.setMetadata("cp_marked",
                        new org.bukkit.metadata.FixedMetadataValue(plugin, true));
                target.getWorld().spawnParticle(Particle.DUST, target.getLocation().add(0, 1.5, 0), 20,
                        0.3, 0.4, 0.3, new Particle.DustOptions(org.bukkit.Color.RED, 1.4f));
                p.sendActionBar(Component.text("Hedef isaretlendi - sonraki darbe infaz", NamedTextColor.RED));
            }
        }
    }

    static double maxHealth(LivingEntity le) {
        var attr = le.getAttribute(Attribute.MAX_HEALTH);
        return attr == null ? 20.0 : attr.getValue();
    }
}
