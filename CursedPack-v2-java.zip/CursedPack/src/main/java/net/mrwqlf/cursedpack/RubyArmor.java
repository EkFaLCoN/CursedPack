package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Alt set (bot+pantolon)  : Atilim - comelerek zipla, 6 blok ileri firla (20 sn)
 * Ust set (kask+goguslük) : Kan Bagi - can %35 altina dusunce Direnc II
 * Tam set                 : Olumsuz Kivilcim - olumcul darbede 1 kalple ayakta kal (10 dk)
 */
public final class RubyArmor implements Listener {

    private final CursedPack plugin;
    private final Map<UUID, Long> dashCd = new HashMap<>();
    private final Map<UUID, Long> sparkCd = new HashMap<>();

    public RubyArmor(CursedPack plugin) {
        this.plugin = plugin;
        startBloodBond();
    }

    private static boolean isRuby(ItemStack st, String piece) {
        return CursedPack.isModel(st, "ruby/ruby_" + piece);
    }

    static boolean lowerSet(Player p) {
        PlayerInventory i = p.getInventory();
        return isRuby(i.getBoots(), "boots") && isRuby(i.getLeggings(), "leggings");
    }

    static boolean upperSet(Player p) {
        PlayerInventory i = p.getInventory();
        return isRuby(i.getHelmet(), "helmet") && isRuby(i.getChestplate(), "chestplate");
    }

    static boolean fullSet(Player p) {
        return lowerSet(p) && upperSet(p);
    }

    // --- Atilim ---
    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (!e.isSneaking()) return;
        Player p = e.getPlayer();
        if (!lowerSet(p)) return;
        if (p.isOnGround()) return; // comelerek ZIPLA -> havada olmali

        int cd = plugin.getConfig().getInt("ruby.armor.dash-cooldown-seconds", 20);
        long now = System.currentTimeMillis();
        if (now < dashCd.getOrDefault(p.getUniqueId(), 0L)) {
            long left = (dashCd.get(p.getUniqueId()) - now + 999) / 1000;
            p.sendActionBar(Component.text("Atilim: " + left + "s", NamedTextColor.GRAY));
            return;
        }
        dashCd.put(p.getUniqueId(), now + cd * 1000L);

        Vector dir = p.getLocation().getDirection().setY(0).normalize().multiply(1.6);
        dir.setY(0.25);
        p.setVelocity(dir);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 1f, 1.2f);
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 25, 0.3, 0.2, 0.3, 0.05);
        p.sendActionBar(Component.text("Atilim!", NamedTextColor.AQUA));
    }

    // --- Kan Bagi ---
    private void startBloodBond() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player p : plugin.getServer().getOnlinePlayers()) {
                    if (!upperSet(p)) continue;
                    double max = RubyWeapons.maxHealth(p);
                    if (p.getHealth() <= max * 0.35) {
                        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 1, true, false, true));
                    }
                }
            }
        }.runTaskTimer(plugin, 40L, 20L);
    }

    // --- Olumsuz Kivilcim ---
    @EventHandler(ignoreCancelled = true)
    public void onLethal(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!fullSet(p)) return;
        if (p.getHealth() - e.getFinalDamage() > 0) return;

        int cdMin = plugin.getConfig().getInt("ruby.armor.spark-cooldown-minutes", 10);
        long now = System.currentTimeMillis();
        if (now < sparkCd.getOrDefault(p.getUniqueId(), 0L)) return;
        sparkCd.put(p.getUniqueId(), now + cdMin * 60_000L);

        e.setCancelled(true);
        p.setHealth(2.0);
        p.setFireTicks(0);
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 0.8f);
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0), 80, 0.4, 0.6, 0.4, 0.4);
        p.sendMessage(Component.text("Olumsuz Kivilcim seni ayakta tuttu!", NamedTextColor.LIGHT_PURPLE));
    }
}
