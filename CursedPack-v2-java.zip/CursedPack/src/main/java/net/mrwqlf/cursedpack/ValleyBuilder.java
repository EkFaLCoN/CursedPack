package net.mrwqlf.cursedpack;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Cursed Valley haritasini kurar. Datapack fonksiyonu yerine, jar icindeki
 * komut listesini tik basina X komut olacak sekilde calistirir.
 * Boylece sunucu donmaz (datapack surumunde tek tikta calisip lag yapiyordu).
 */
public final class ValleyBuilder {

    private final CursedPack plugin;
    private BukkitRunnable running;
    private String runningWhat = "";
    private int total, done;

    public ValleyBuilder(CursedPack plugin) { this.plugin = plugin; }

    public void handle(CommandSender s, String[] a) {
        if (a.length < 2) {
            s.sendMessage("§6Cursed Valley§7 - /cursedpack valley <prep|build|status|stop|finish> [sektor 1-9]");
            s.sendMessage("§7Sira: once §fprep §7(chunk yukle, 2 dk bekle), sonra §fbuild§7.");
            return;
        }
        switch (a[1].toLowerCase()) {
            case "status" -> {
                if (running == null) s.sendMessage("§7Calisan islem yok.");
                else s.sendMessage("§e" + runningWhat + " §7- " + done + "/" + total
                        + " (%" + (total == 0 ? 0 : done * 100 / total) + ")");
            }
            case "stop" -> {
                if (running == null) { s.sendMessage("§7Zaten calisan islem yok."); return; }
                running.cancel();
                running = null;
                s.sendMessage("§cIslem durduruldu.");
            }
            case "finish" -> run(s, "finish", finishCommands());
            case "prep", "build" -> {
                if (a.length < 3) { s.sendMessage("§cSektor numarasi ver: 1-9"); return; }
                int n;
                try { n = Integer.parseInt(a[2]); } catch (NumberFormatException ex) {
                    s.sendMessage("§cGecersiz sektor."); return;
                }
                if (n < 1 || n > 9) { s.sendMessage("§cSektor 1-9 arasi olmali."); return; }

                String kind = a[1].toLowerCase();
                List<String> cmds = new ArrayList<>();
                if (kind.equals("prep")) {
                    cmds.addAll(load("s" + n + ".prep"));
                } else {
                    cmds.addAll(load("s" + n + ".build"));
                    cmds.addAll(load("s" + n + ".blocks"));
                    cmds.addAll(load("s" + n + ".done"));
                }
                if (cmds.isEmpty()) { s.sendMessage("§cSektor " + n + " icin veri bulunamadi."); return; }
                run(s, kind + " s" + n, cmds);
            }
            default -> s.sendMessage("§cBilinmeyen: " + a[1]);
        }
    }

    private List<String> finishCommands() {
        return List.of(
                "forceload remove all",
                "weather clear 1000000",
                "setworldspawn 0 -60 -1046"
        );
    }

    private List<String> load(String name) {
        List<String> out = new ArrayList<>();
        try (InputStream in = plugin.getResource("valley/" + name + ".txt")) {
            if (in == null) return out;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (!line.isEmpty() && !line.startsWith("#")) out.add(line);
                }
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Valley dosyasi okunamadi: " + name + " - " + e.getMessage());
        }
        return out;
    }

    private void run(CommandSender s, String what, List<String> cmds) {
        if (running != null) {
            s.sendMessage("§cZaten bir islem calisiyor: " + runningWhat + " (§f/cursedpack valley stop§c)");
            return;
        }
        int perTick = plugin.getConfig().getInt("valley.commands-per-tick", 20);
        runningWhat = what;
        total = cmds.size();
        done = 0;
        s.sendMessage("§a" + what + " basladi: §f" + total + " komut §7(tik basina " + perTick + ")");

        running = new BukkitRunnable() {
            int i = 0;
            int lastPercent = -1;

            @Override
            public void run() {
                var console = Bukkit.getConsoleSender();
                for (int k = 0; k < perTick && i < cmds.size(); k++, i++) {
                    String c = cmds.get(i);
                    if (c.startsWith("say ")) continue; // datapack'in duyurulari
                    try {
                        Bukkit.dispatchCommand(console, c);
                    } catch (Throwable t) {
                        plugin.getLogger().warning("Komut hatasi: " + c + " -> " + t.getMessage());
                    }
                }
                done = i;
                int pct = total == 0 ? 100 : i * 100 / total;
                if (pct / 10 != lastPercent / 10) {
                    lastPercent = pct;
                    s.sendMessage("§7" + runningWhat + ": §f%" + pct);
                }
                if (i >= cmds.size()) {
                    s.sendMessage("§a" + runningWhat + " tamamlandi.");
                    running = null;
                    cancel();
                }
            }
        };
        running.runTaskTimer(plugin, 1L, 1L);
    }
}
