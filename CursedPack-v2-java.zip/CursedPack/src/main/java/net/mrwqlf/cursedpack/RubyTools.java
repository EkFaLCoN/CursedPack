package net.mrwqlf.cursedpack;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public final class RubyTools implements Listener {

    private final CursedPack plugin;
    private final Set<java.util.UUID> busy = new HashSet<>();

    public RubyTools(CursedPack plugin) { this.plugin = plugin; }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (busy.contains(p.getUniqueId())) return;

        ItemStack hand = p.getInventory().getItemInMainHand();
        String model = CursedPack.modelOf(hand);

        if (model.endsWith("ruby/ruby_axe") && Tag.LOGS.isTagged(e.getBlock().getType())) {
            chopTree(p, e.getBlock(), hand);
        } else if (model.endsWith("ruby/ruby_shovel")) {
            digArea(p, e.getBlock(), hand);
        } else if (model.endsWith("ruby/ruby_hoe")) {
            harvest(p, e.getBlock(), hand);
        }
    }

    /** Agac Yikici: bagli kutukleri ve yapraklari kirar. */
    private void chopTree(Player p, Block origin, ItemStack tool) {
        int max = plugin.getConfig().getInt("ruby.axe.max-blocks", 200);
        Set<Block> logs = new HashSet<>();
        Set<Block> leaves = new HashSet<>();
        ArrayDeque<Block> queue = new ArrayDeque<>();
        queue.add(origin);
        Set<Block> seen = new HashSet<>();
        seen.add(origin);

        while (!queue.isEmpty() && logs.size() + leaves.size() < max) {
            Block b = queue.poll();
            boolean isLog = Tag.LOGS.isTagged(b.getType());
            boolean isLeaf = Tag.LEAVES.isTagged(b.getType());
            if (!isLog && !isLeaf) continue;
            if (isLog) logs.add(b); else leaves.add(b);
            if (isLeaf) continue; // yapraktan yayilma yok, sadece kutuklerden

            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        Block n = b.getRelative(dx, dy, dz);
                        if (seen.add(n)) queue.add(n);
                    }
        }

        busy.add(p.getUniqueId());
        try {
            for (Block b : logs) { b.breakNaturally(tool); damage(p, tool, 1); }
            for (Block b : leaves) {
                b.breakNaturally(tool);
                double r = ThreadLocalRandom.current().nextDouble() * 100.0;
                if (r < 0.005) b.getWorld().dropItemNaturally(b.getLocation(),
                        new ItemStack(Material.ENCHANTED_GOLDEN_APPLE));
                else if (r < 1.0) b.getWorld().dropItemNaturally(b.getLocation(),
                        new ItemStack(Material.GOLDEN_APPLE));
            }
        } finally {
            busy.remove(p.getUniqueId());
        }
        p.playSound(p.getLocation(), Sound.BLOCK_WOOD_BREAK, 1f, 0.8f);
    }

    /** Kepce: bakis yonune gore 3x3 kaz. */
    private void digArea(Player p, Block center, ItemStack tool) {
        Vector dir = p.getLocation().getDirection();
        boolean vertical = Math.abs(dir.getY()) < 0.6;

        busy.add(p.getUniqueId());
        try {
            for (int a = -1; a <= 1; a++)
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    Block t;
                    if (!vertical) {
                        t = center.getRelative(a, 0, b);           // yatay duzlem
                    } else if (Math.abs(dir.getX()) > Math.abs(dir.getZ())) {
                        t = center.getRelative(0, a, b);           // X'e bakiyor
                    } else {
                        t = center.getRelative(a, b, 0);           // Z'ye bakiyor
                    }
                    if (!isDiggable(t.getType())) continue;
                    t.breakNaturally(tool);
                    damage(p, tool, 1);
                }
        } finally {
            busy.remove(p.getUniqueId());
        }
    }

    private boolean isDiggable(Material m) {
        return Tag.MINEABLE_SHOVEL.isTagged(m);
    }

    /** Toplu Hasat: 5x5 olgun ekin, tekrar ekilir. */
    private void harvest(Player p, Block center, ItemStack tool) {
        if (!(center.getBlockData() instanceof Ageable ag) || ag.getAge() < ag.getMaximumAge()) return;

        busy.add(p.getUniqueId());
        try {
            for (int dx = -2; dx <= 2; dx++)
                for (int dz = -2; dz <= 2; dz++) {
                    Block b = center.getRelative(dx, 0, dz);
                    if (!(b.getBlockData() instanceof Ageable a2)) continue;
                    if (a2.getAge() < a2.getMaximumAge()) continue;
                    Material type = b.getType();
                    b.breakNaturally(tool);
                    b.setType(type);
                    if (b.getBlockData() instanceof Ageable fresh) {
                        fresh.setAge(0);
                        b.setBlockData(fresh);
                    }
                    damage(p, tool, 1);
                }
        } finally {
            busy.remove(p.getUniqueId());
        }
        p.playSound(p.getLocation(), Sound.ITEM_CROP_PLANT, 1f, 1.2f);
    }

    /** Kirilmazlik seviyesine gore dayaniklilik harca. */
    static void damage(Player p, ItemStack tool, int amount) {
        if (p.getGameMode() == org.bukkit.GameMode.CREATIVE) return;
        int unb = tool.getEnchantmentLevel(Enchantment.UNBREAKING);
        if (unb > 0 && ThreadLocalRandom.current().nextInt(unb + 1) != 0) return;
        if (tool.getItemMeta() instanceof Damageable d) {
            d.setDamage(d.getDamage() + amount);
            tool.setItemMeta(d);
            if (d.getDamage() >= tool.getType().getMaxDurability()) {
                tool.setAmount(0);
                p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
            }
        }
    }
}
