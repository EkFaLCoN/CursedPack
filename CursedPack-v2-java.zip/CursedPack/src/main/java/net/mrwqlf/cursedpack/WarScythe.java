package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Sag tik: tirpani firlatir. 10 blok gider, degdigi canlilari kendine ceker,
 * sonra kaybolur. Cooldown suresince tekrar firlatilamaz.
 */
public final class WarScythe implements Listener {

    private static final String MODEL = "warscythe/warscythe";
    private final CursedPack plugin;
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public WarScythe(CursedPack plugin) { this.plugin = plugin; }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack held = e.getPlayer().getInventory().getItemInMainHand();
        if (!CursedPack.isModel(held, MODEL)) return;

        e.setCancelled(true);
        Player p = e.getPlayer();

        int cdSec = plugin.getConfig().getInt("warscythe.cooldown-seconds", 8);
        long now = System.currentTimeMillis();
        long until = cooldown.getOrDefault(p.getUniqueId(), 0L);
        if (now < until) {
            long left = (until - now + 999) / 1000;
            p.sendActionBar(Component.text("Tirpan hazir degil: " + left + "s", NamedTextColor.GRAY));
            return;
        }
        cooldown.put(p.getUniqueId(), now + cdSec * 1000L);

        throwScythe(p, held);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 0.7f);
        countdown(p, cdSec);
    }

    private void throwScythe(Player owner, ItemStack visual) {
        Location start = owner.getEyeLocation().add(owner.getLocation().getDirection().multiply(0.8));
        Vector dir = owner.getLocation().getDirection().normalize().multiply(0.5);

        ItemDisplay disp = owner.getWorld().spawn(start, ItemDisplay.class, d -> {
            ItemStack copy = visual.clone();
            copy.setAmount(1);
            d.setItemStack(copy);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setInterpolationDuration(1);
            d.setTeleportDuration(1);
            Transformation t = d.getTransformation();
            t.getScale().set(1.6f, 1.6f, 1.6f);
            d.setTransformation(t);
        });

        final double pullPower = plugin.getConfig().getDouble("warscythe.pull-power", 1.1);
        final double damage = plugin.getConfig().getDouble("warscythe.damage", 6.0);

        new BukkitRunnable() {
            int life = 20;
            float spin = 0f;

            @Override
            public void run() {
                if (life-- <= 0 || !disp.isValid()) {
                    if (disp.isValid()) {
                        disp.getWorld().spawnParticle(Particle.SWEEP_ATTACK, disp.getLocation(), 1, 0, 0, 0, 0);
                        disp.remove();
                    }
                    cancel();
                    return;
                }

                Location loc = disp.getLocation().add(dir);
                disp.teleport(loc);

                // kendi ekseninde don
                spin += 25f;
                if (spin >= 360f) spin -= 360f;
                Transformation t = disp.getTransformation();
                t.getLeftRotation().set(new AxisAngle4f((float) Math.toRadians(spin), new Vector3f(0, 0, 1)));
                disp.setTransformation(t);

                loc.getWorld().spawnParticle(Particle.CRIT, loc, 3, 0.1, 0.1, 0.1, 0.02);
                loc.getWorld().spawnParticle(Particle.ENCHANTED_HIT, loc, 1, 0, 0, 0, 0);

                // carpisma: sahibi haric canlilari cek
                for (Entity ent : loc.getWorld().getNearbyEntities(loc, 2.5, 2.5, 2.5)) {
                    if (!(ent instanceof LivingEntity le)) continue;
                    if (le.equals(owner)) continue;
                    if (le instanceof ArmorStand || le instanceof Display) continue;

                    Vector pull = owner.getLocation().toVector()
                            .subtract(le.getLocation().toVector()).normalize().multiply(pullPower);
                    pull.setY(Math.max(0.25, pull.getY() * 0.5));
                    le.setVelocity(pull);
                    le.damage(damage, owner);
                    le.getWorld().playSound(le.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.6f);
                    le.getWorld().spawnParticle(Particle.SWEEP_ATTACK, le.getLocation().add(0, 1, 0), 1);
                }

                // duvara girdiyse dur
                if (loc.getBlock().getType().isSolid()) {
                    loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, loc, 1);
                    disp.remove();
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void countdown(Player p, int seconds) {
        new BukkitRunnable() {
            int left = seconds;
            @Override
            public void run() {
                if (!p.isOnline()) { cancel(); return; }
                if (left <= 0) {
                    p.sendActionBar(Component.text("Tirpan hazir!", NamedTextColor.GREEN));
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.6f);
                    cancel();
                    return;
                }
                p.sendActionBar(Component.text("Tirpan: " + left + "s", NamedTextColor.DARK_RED));
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
}
