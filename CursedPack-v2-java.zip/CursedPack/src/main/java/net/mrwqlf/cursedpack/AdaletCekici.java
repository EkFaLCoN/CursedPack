package net.mrwqlf.cursedpack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * 10+ bloktan dusunce, elde Adalet Cekici varsa %40 ihtimalle deprem.
 * Datapack'te fall_distance takibi vardi; Java'da dogrudan dusme hasari olayindan aliyoruz.
 */
public final class AdaletCekici implements Listener {

    private static final String MODEL = "adaletcekici/adaletcekici";
    private final CursedPack plugin;

    public AdaletCekici(CursedPack plugin) { this.plugin = plugin; }

    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (!CursedPack.isModel(p.getInventory().getItemInMainHand(), MODEL)) return;

        double minFall = plugin.getConfig().getDouble("cekic.min-fall", 10.0);
        if (p.getFallDistance() < minFall) return;

        int chance = plugin.getConfig().getInt("cekic.chance-percent", 40);
        if (ThreadLocalRandom.current().nextInt(100) >= chance) {
            p.sendActionBar(Component.text("Deprem tetiklenmedi", NamedTextColor.DARK_GRAY));
            return;
        }
        quake(p);
    }

    private void quake(Player caster) {
        Location c = caster.getLocation();
        double radius = plugin.getConfig().getDouble("cekic.radius", 2.5);
        double damage = plugin.getConfig().getDouble("cekic.damage", 8.0);

        c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 2.5f, 0.5f);
        c.getWorld().playSound(c, Sound.BLOCK_DEEPSLATE_BRICKS_BREAK, 3f, 0.6f);
        c.getWorld().playSound(c, Sound.ENTITY_RAVAGER_STUNNED, 1.5f, 0.8f);

        c.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, c.clone().add(0, 0.2, 0), 1, 0, 0, 0, 0);
        c.getWorld().spawnParticle(Particle.BLOCK, c.clone().add(0, 0.4, 0), 220, 2.2, 0.5, 2.2, 0.35,
                Material.DIRT.createBlockData());
        c.getWorld().spawnParticle(Particle.BLOCK, c.clone().add(0, 0.4, 0), 120, 2.2, 0.5, 2.2, 0.3,
                Material.STONE.createBlockData());
        c.getWorld().spawnParticle(Particle.CRIT, c.clone().add(0, 0.4, 0), 90, 2.2, 0.4, 2.2, 0.4);
        c.getWorld().spawnParticle(Particle.END_ROD, c.clone().add(0, 0.1, 0), 40, 2.5, 0.05, 2.5, 0);

        int hits = 0;
        for (Entity ent : c.getWorld().getNearbyEntities(c, radius, 1.5, radius)) {
            if (!(ent instanceof LivingEntity le)) continue;
            if (le.equals(caster)) continue;
            if (isImmune(le)) continue;

            le.damage(damage, caster);
            Vector kb = le.getLocation().toVector().subtract(c.toVector());
            if (kb.lengthSquared() < 0.01) kb = new Vector(0, 1, 0);
            kb.normalize().multiply(0.8).setY(0.6);
            le.setVelocity(kb);
            hits++;
        }

        caster.sendActionBar(Component.text("DEPREM! " + hits + " hedef", NamedTextColor.GOLD));
    }

    /** Datapack'teki quake_immune tag'inin karsiligi. */
    private boolean isImmune(LivingEntity le) {
        return switch (le.getType()) {
            case ARMOR_STAND, ITEM_FRAME, GLOW_ITEM_FRAME, PAINTING, ENDER_DRAGON, WITHER -> true;
            default -> false;
        };
    }
}
