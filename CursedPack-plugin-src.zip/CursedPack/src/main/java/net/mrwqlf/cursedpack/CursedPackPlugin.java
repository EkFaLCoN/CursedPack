package net.mrwqlf.cursedpack;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class CursedPackPlugin extends JavaPlugin implements org.bukkit.command.TabCompleter {

    /** /cursedpack give <isim> -> calistirilacak datapack fonksiyonu */
    private static final Map<String, String> ITEMS = new LinkedHashMap<>();
    static {
        ITEMS.put("cekic",       "adaletcekici:give");
        ITEMS.put("scythe",      "warscythe:give");
        ITEMS.put("ruby",        "ruby:give");
        ITEMS.put("ruby_dust",   "ruby:give_dust");
        ITEMS.put("ruby_block",  "ruby:give_block");
        ITEMS.put("sword",       "ruby:give_sword");
        ITEMS.put("axe",         "ruby:give_axe");
        ITEMS.put("war_axe",     "ruby:give_war_axe");
        ITEMS.put("pickaxe",     "ruby:give_pickaxe");
        ITEMS.put("shovel",      "ruby:give_shovel");
        ITEMS.put("hoe",         "ruby:give_hoe");
        ITEMS.put("spear",       "ruby:give_spear");
        ITEMS.put("armor",       "ruby:give_armor");
        ITEMS.put("helmet",      "ruby:give_helmet");
        ITEMS.put("chestplate",  "ruby:give_chestplate");
        ITEMS.put("leggings",    "ruby:give_leggings");
        ITEMS.put("boots",       "ruby:give_boots");
    }


    private static final String PACK_RESOURCE = "CursedPack.zip";
    private static final String PACK_FILE = "CursedPack.zip";

    private final List<String> installedIn = new ArrayList<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        int n = installAll();
        getLogger().info("CursedPack " + n + " dunyaya kuruldu: " + installedIn);
        var cmd = getCommand("cursedpack");
        if (cmd != null) cmd.setTabCompleter(this);

        // Sunucu tam acildiktan sonra datapack'i etkinlestir + reload
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (getConfig().getBoolean("auto-enable", true)) {
                enableAndReload(Bukkit.getConsoleSender());
            }
        }, 40L);
    }

    /** Jar icindeki paketi tum (ya da config'te yazan) dunyalarin datapacks klasorune kopyalar. */
    private int installAll() {
        installedIn.clear();
        List<String> only = getConfig().getStringList("worlds");
        int count = 0;
        for (World w : Bukkit.getWorlds()) {
            if (!only.isEmpty() && !only.contains(w.getName())) continue;
            if (install(w)) {
                installedIn.add(w.getName());
                count++;
            }
        }
        return count;
    }

    private boolean install(World world) {
        try {
            File dir = new File(world.getWorldFolder(), "datapacks");
            if (!dir.exists() && !dir.mkdirs()) {
                getLogger().warning(world.getName() + " icin datapacks klasoru olusturulamadi.");
                return false;
            }
            Path target = new File(dir, PACK_FILE).toPath();

            byte[] jarBytes;
            try (InputStream in = getResource(PACK_RESOURCE)) {
                if (in == null) {
                    getLogger().severe("Jar icinde " + PACK_RESOURCE + " yok!");
                    return false;
                }
                jarBytes = in.readAllBytes();
            }

            if (Files.exists(target) && sha1(Files.readAllBytes(target)).equals(sha1(jarBytes))) {
                return true; // zaten guncel
            }

            Path tmp = target.resolveSibling(PACK_FILE + ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                out.write(jarBytes);
            }
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (Exception e) {
            getLogger().severe("Kurulum hatasi (" + world.getName() + "): " + e.getMessage());
            return false;
        }
    }

    private void enableAndReload(CommandSender sender) {
        if (installedIn.isEmpty()) {
            sender.sendMessage("§cHicbir dunyaya kurulmadi.");
            return;
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "datapack enable \"file/" + PACK_FILE + "\"");
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "minecraft:reload");
        sender.sendMessage("§aCursedPack etkinlestirildi ve datapack'ler yeniden yuklendi.");
    }

    private static String sha1(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest(data)) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private void handleGive(CommandSender s, String[] args) {
        if (args.length < 2) {
            s.sendMessage("§cKullanim: /cursedpack give <esya> [oyuncu]");
            s.sendMessage("§7Esyalar: §f" + String.join(", ", ITEMS.keySet()));
            return;
        }
        String fn = ITEMS.get(args[1].toLowerCase());
        if (fn == null) {
            s.sendMessage("§cBoyle bir esya yok. /cursedpack list");
            return;
        }
        org.bukkit.entity.Player target;
        if (args.length >= 3) {
            target = Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                s.sendMessage("§cOyuncu bulunamadi: " + args[2]);
                return;
            }
        } else if (s instanceof org.bukkit.entity.Player p) {
            target = p;
        } else {
            s.sendMessage("§cKonsoldan oyuncu adi yazmalisin.");
            return;
        }

        boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "execute as " + target.getName() + " at " + target.getName() + " run function " + fn);
        if (ok) {
            s.sendMessage("§a" + args[1].toLowerCase() + " -> " + target.getName());
            if (!target.equals(s)) target.sendMessage("§aBir esya aldin: §f" + args[1].toLowerCase());
        } else {
            s.sendMessage("§cFonksiyon calismadi: " + fn + " §7(datapack yuklu mu?)");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String a : List.of("give", "list", "reload", "info"))
                if (a.startsWith(args[0].toLowerCase())) out.add(a);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (String k : ITEMS.keySet())
                if (k.startsWith(args[1].toLowerCase())) out.add(k);
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            for (var p : Bukkit.getOnlinePlayers())
                if (p.getName().toLowerCase().startsWith(args[2].toLowerCase())) out.add(p.getName());
        }
        return out;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] args) {
        if (args.length == 0) {
            s.sendMessage("§6CursedPack §7- /cursedpack <give|list|reload|info>");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                reloadConfig();
                int n = installAll();
                enableAndReload(s);
                s.sendMessage("§a" + n + " dunyaya yazildi.");
            }
            case "info" -> {
                s.sendMessage("§6CursedPack §7v" + getPluginMeta().getVersion());
                s.sendMessage("§7Icerik: adaletcekici, ruby, warscythe, cursedvalley4");
                s.sendMessage("§7Kurulu dunyalar: §f" + installedIn);
            }
            case "give" -> handleGive(s, args);
            case "list" -> s.sendMessage("§6Esyalar: §f" + String.join(", ", ITEMS.keySet()));
            default -> s.sendMessage("§cBilinmeyen alt komut. /cursedpack <give|list|reload|info>");
        }
        return true;
    }
}
