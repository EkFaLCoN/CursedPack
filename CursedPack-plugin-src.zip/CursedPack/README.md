# CursedPack

4 datapack tek pakette + tek plugin jar:
- adaletcekici (Adalet Cekici)
- ruby (Ruby Ore)
- warscythe (War Scythe)
- cursedvalley4 (Cursed Valley v4 harita builder)

## Kurulum (exaroton)
1. GitHub'a bu klasoru yukle -> Actions calisir -> `CursedPack.jar` artifact'ini indir.
2. Panelden `plugins/` klasorune jar'i yukle, sunucuyu yeniden baslat.
3. Plugin, jar icindeki birlesik datapack'i her dunyanin `datapacks/` klasorune yazar,
   sonra `datapack enable` + `/minecraft:reload` calistirir.

## Komutlar
- `/cursedpack info`
- `/cursedpack reload` (jar guncellendiginde tekrar yazar ve reload eder)

## Not
Resourcepack (ruby / adalet cekici 3D modelleri) ayri: panelden server.properties'te
`resource-pack` URL'sini vermeye devam et.

## Esya alma
- `/cursedpack give <esya> [oyuncu]`
- `/cursedpack list` — tum esyalar

Esyalar: cekic, scythe, ruby, ruby_dust, ruby_block, sword, axe, war_axe,
pickaxe, shovel, hoe, spear, armor, helmet, chestplate, leggings, boots

## Zip ile yukleme
Repo'nun koküne bu zip'i at + `.github/workflows/build.yml` dosyasini koy.
Actions zip'i acar, pom.xml'i bulur, derler ve `CursedPack.jar` artifact'i uretir.
